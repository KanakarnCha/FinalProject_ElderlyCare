package com.example.BackendFinalProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendFinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendFinalProjectApplication.class, args);
	}

}
