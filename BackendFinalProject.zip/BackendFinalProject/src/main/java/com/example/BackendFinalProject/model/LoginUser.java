package com.example.BackendFinalProject.model;

import lombok.Data;

@Data
public class LoginUser {
    private String username;
    private String password;
}
