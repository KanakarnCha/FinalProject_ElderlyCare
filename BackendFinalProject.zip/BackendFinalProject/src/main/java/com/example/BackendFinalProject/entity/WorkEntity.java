package com.example.BackendFinalProject.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity(name = "tb_work_order")
@Data
public class WorkEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private Long workOrderId;
    private String goalLat;
    private String goalLong;
    private String startLat;
    private String startLong;
    private String workDescription;
    private int workStatus;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private UserEntity userEntity;

    @JsonIgnore
    @OneToMany(mappedBy = "workEntity")
    private List<MatchEntity> matchEntities;


}
