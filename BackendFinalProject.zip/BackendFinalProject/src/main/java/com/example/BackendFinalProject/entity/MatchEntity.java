package com.example.BackendFinalProject.entity;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.time.ZoneId;

@Data
@Entity(name = "tb_match")
public class MatchEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false)
    private Long matchId;
    private String userId;
    private int status;
    private final LocalDateTime timeStamp = LocalDateTime.now(ZoneId.of("UTC+07:00"));


    @ManyToOne
    @JoinColumn(name = "order_id",unique = true)
    private WorkEntity workEntity;

    @ManyToOne
    @JoinColumn(name = "volunteer_id")
    private VolunteerEntity volunteerEntity;


}
