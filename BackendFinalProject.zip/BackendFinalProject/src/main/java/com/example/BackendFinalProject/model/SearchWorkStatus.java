package com.example.BackendFinalProject.model;

import lombok.Data;

@Data
public class SearchWorkStatus {
    int workStatus;
}
