package com.example.BackendFinalProject.services;

import com.example.BackendFinalProject.entity.UserEntity;
import com.example.BackendFinalProject.entity.WorkEntity;
import com.example.BackendFinalProject.exception.BaseException;
import com.example.BackendFinalProject.exception.UserException;
import com.example.BackendFinalProject.model.AddWorkModel;
import com.example.BackendFinalProject.model.SearchWorkStatus;
import com.example.BackendFinalProject.repository.UserRepository;
import com.example.BackendFinalProject.repository.WorkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;

@Service
public class WorkService {
    @Autowired
    WorkRepository workRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    JwtService jwtService;

    public List<WorkEntity> findAllWork(){
        return workRepository.findAll();
    }
    public List<WorkEntity> findUser(HttpServletRequest httpServletRequest) throws BaseException {
        String token = jwtService.getToken(httpServletRequest);
        if (userRepository.findById(token).isEmpty()){
            throw UserException.failError();
        }
        Optional<UserEntity> data =  userRepository.findById(token);
        UserEntity user = data.get();
        List<WorkEntity> workEntity =  workRepository.findAllByUserEntity(user);
       // System.out.println(workOrder.get(0).getUserEntity().getUserId());
        return workEntity;
    }

    public void createWork(HttpServletRequest request, AddWorkModel addWorkModel) throws BaseException {
        String token = jwtService.getToken(request);
        if (userRepository.findById(token).isEmpty()){
            throw UserException.failError();
        }

        Optional<UserEntity> data =  userRepository.findById(token);
        if (workRepository.existsByUserEntity_userIdAndWorkStatus(token,0)){
            throw UserException.failError();
        }
        UserEntity user = data.get();
        user.setUserStatus(1);
        WorkEntity workEntity = new WorkEntity();
        workEntity.setUserEntity(user);
        workEntity.setStartLong(addWorkModel.getStartLong());
        workEntity.setStartLat(addWorkModel.getStartLat());
        workEntity.setGoalLong(addWorkModel.getGoalLong());
        workEntity.setGoalLat(addWorkModel.getGoalLat());
        workEntity.setWorkStatus(0);
        workEntity.setWorkDescription(addWorkModel.getWorkDescription());
        workRepository.save(workEntity);
    }

    public List<WorkEntity> findWorkNotMatch(int workStatus){
        return workRepository.findAllByWorkStatus(workStatus);
    }
    public WorkEntity findByIdOrder(int orderId) throws BaseException {
        Optional<WorkEntity> work = workRepository.findById((long) orderId);
        if (work.isEmpty()){
            throw UserException.failError();
        }else{
            return work.get();
        }

    }

    public WorkEntity findByWorkInQ(HttpServletRequest request, SearchWorkStatus workStatus) throws BaseException {
        String token = jwtService.getToken(request);
        Optional<WorkEntity> work = workRepository.findByWorkStatusAndUserEntity_UserId(workStatus.getWorkStatus(), token);
        if (work.isEmpty()){
            throw UserException.failError();
        }

        return work.get();
    }
}
