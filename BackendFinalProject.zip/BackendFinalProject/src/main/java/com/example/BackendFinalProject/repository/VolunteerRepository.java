package com.example.BackendFinalProject.repository;

import com.example.BackendFinalProject.entity.VolunteerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VolunteerRepository extends JpaRepository<VolunteerEntity,String> {

    Optional<VolunteerEntity> findByVolunteerUsername(String s);

    boolean existsByVolunteerUsername(String s);
}
