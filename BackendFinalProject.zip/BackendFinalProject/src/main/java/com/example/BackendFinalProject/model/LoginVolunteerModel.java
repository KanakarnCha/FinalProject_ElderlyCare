package com.example.BackendFinalProject.model;

import lombok.Data;

@Data
public class LoginVolunteerModel {
    private String volunteerUsername;
    private String volunteerPassword;
}
