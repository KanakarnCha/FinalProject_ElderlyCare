package com.example.BackendFinalProject.controller;


import com.example.BackendFinalProject.Dto.ResMessage;
import com.example.BackendFinalProject.entity.MatchEntity;
import com.example.BackendFinalProject.entity.UserEntity;
import com.example.BackendFinalProject.entity.VolunteerEntity;
import com.example.BackendFinalProject.entity.WorkEntity;
import com.example.BackendFinalProject.exception.BaseException;
import com.example.BackendFinalProject.exception.UserException;
import com.example.BackendFinalProject.model.FindMatchVolunteerModel;
import com.example.BackendFinalProject.model.MatchingModel;

import com.example.BackendFinalProject.model.SearchMatchIdModel;
import com.example.BackendFinalProject.model.SearchSuccessWorkModel;
import com.example.BackendFinalProject.repository.MatchRepository;
import com.example.BackendFinalProject.repository.UserRepository;
import com.example.BackendFinalProject.repository.VolunteerRepository;
import com.example.BackendFinalProject.repository.WorkRepository;
import com.example.BackendFinalProject.services.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/control/api/")
public class MatchController {

    @Autowired
    MatchRepository matchRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    VolunteerRepository volunteerRepository;
    @Autowired
    WorkRepository workRepository;

    @Autowired
    JwtService jwtService;

    @PostMapping("matching")
    public ResponseEntity<MatchEntity> matching(HttpServletRequest httpServletRequest, @RequestBody MatchingModel matchingModel) throws BaseException {
        String tokenVolunteer = jwtService.getToken(httpServletRequest);
        Optional<VolunteerEntity> volunteerData = volunteerRepository.findById(tokenVolunteer);
        Optional<WorkEntity> orderWork = workRepository.findById((long) matchingModel.getOrderWork());
       // Optional<MatchEntity> matchEntity = matchRepository.findByUserId(orderWork.get().getUserEntity().getUserId());

        if (volunteerData.isEmpty()) {
            throw UserException.failError();
        }
        if (orderWork.isEmpty()) {
            throw UserException.orderFailError();
        }
        volunteerData.get().setVolunteerStatus(1);
        WorkEntity oreder = orderWork.get();
        oreder.setWorkStatus(1);
        workRepository.save(oreder);
        MatchEntity match = new MatchEntity();
        match.setUserId(orderWork.get().getUserEntity().getUserId());
        match.setVolunteerEntity(volunteerData.get());
        match.setWorkEntity(orderWork.get());
        match.setStatus(1);
        System.out.println(orderWork.get().getUserEntity().getUserId());

        return new ResponseEntity<>(matchRepository.save(match), HttpStatus.OK);
    }

    @GetMapping("showAll")
    public ResponseEntity<List<MatchEntity>> showMatchAll(){
        return new ResponseEntity<>(matchRepository.findAll(),HttpStatus.OK);
    }


    @PostMapping("showWorkSuccess")
    public ResponseEntity<List<MatchEntity>> showWorkDetail(HttpServletRequest httpServletRequest,@RequestBody SearchSuccessWorkModel searchModel){
        String token = jwtService.getToken(httpServletRequest);
        return new ResponseEntity<>(matchRepository.findAllByUserIdAndStatus(token,searchModel.getStatus()),HttpStatus.OK);
    }


    @PostMapping("findActiveMatch")
    public ResponseEntity<List<MatchEntity>> showActiveMatch(HttpServletRequest httpServletRequest,@RequestBody SearchSuccessWorkModel searchModel){
        String token = jwtService.getToken(httpServletRequest);


        return new ResponseEntity<>(matchRepository.findAllByUserIdAndStatus(token,searchModel.getStatus()),HttpStatus.OK);
    }

    @PostMapping("findMatchVolunteer")
    public ResponseEntity<MatchEntity> findMatchOn(HttpServletRequest httpServletRequest, @RequestBody FindMatchVolunteerModel findMatchVolunteerModel) throws BaseException {
        String token = jwtService.getToken(httpServletRequest);
        Optional<MatchEntity> volunteerMatch = matchRepository.findByStatusAndVolunteerEntity_volunteerId(findMatchVolunteerModel.getStatus(), token);
        if (volunteerMatch.isEmpty()){
            throw UserException.orderFailError();
        }
        return new ResponseEntity<>(volunteerMatch.get(),HttpStatus.OK);
    }



    @PostMapping("changeStatusSuccess")
    public ResponseEntity<ResMessage> changeStatusSuccess(HttpServletRequest httpServletRequest,@RequestBody SearchMatchIdModel searchMatchIdModel) throws BaseException {
        String token = jwtService.getToken(httpServletRequest);
        Optional<MatchEntity> matchResOp = matchRepository.findById((long) searchMatchIdModel.getMatchId());
        if (matchResOp.isEmpty()){
            throw UserException.orderFailError();
        }
        Optional<VolunteerEntity> volunteerResOp = volunteerRepository.findById(token);
        if (volunteerResOp.isEmpty()){
            throw UserException.failError();
        }
        volunteerResOp.get().setVolunteerStatus(0);
        volunteerRepository.save(volunteerResOp.get());
        matchResOp.get().setStatus(2);
        matchResOp.get().getWorkEntity().getUserEntity().setUserStatus(0);
        matchRepository.save(matchResOp.get());
        ResMessage resMessage = new ResMessage();
        resMessage.setMessage("Success");
        return new ResponseEntity<>(resMessage,HttpStatus.OK);
    }

    @PostMapping("userChangeStatusSuccess")
    public ResponseEntity<ResMessage> userChangeStatusSuccess(HttpServletRequest httpServletRequest,@RequestBody SearchMatchIdModel searchMatchIdModel) throws BaseException {
        String token = jwtService.getToken(httpServletRequest);
        Optional<MatchEntity> matchResOp = matchRepository.findById((long) searchMatchIdModel.getMatchId());
        if (matchResOp.isEmpty()){
            throw UserException.orderFailError();
        }
        Optional<UserEntity> userEntity = userRepository.findById(token);
        if (userEntity.isEmpty()){
            throw UserException.failError();
        }
        userEntity.get().setUserStatus(0);
        userRepository.save(userEntity.get());
        matchResOp.get().setStatus(2);
        matchResOp.get().getVolunteerEntity().setVolunteerStatus(0);

        matchRepository.save(matchResOp.get());
        ResMessage resMessage = new ResMessage();
        resMessage.setMessage("Success");
        return new ResponseEntity<>(resMessage,HttpStatus.OK);
    }




    @PostMapping("findAllMatchSuccessVolunteer")
    public ResponseEntity<List<MatchEntity>> findAllMatchSuccessVolunteer(HttpServletRequest httpServletRequest,@RequestBody SearchSuccessWorkModel searchSuccessWorkModel){
        String token = jwtService.getToken(httpServletRequest);
        return new ResponseEntity<>(matchRepository.findAllByStatusAndVolunteerEntity_volunteerId(searchSuccessWorkModel.getStatus(),token),HttpStatus.OK);
    }
}
