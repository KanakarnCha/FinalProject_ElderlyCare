package com.example.BackendFinalProject.repository;

import com.example.BackendFinalProject.entity.MatchEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MatchRepository extends JpaRepository<MatchEntity,Long> {
    List<MatchEntity> findAllByUserIdAndStatus(String userid,int status );

    Optional<MatchEntity> findByUserIdAndStatus(String userid,int status );

    Optional<MatchEntity> findByUserId(String userid);


    List<MatchEntity> findAllByStatusAndVolunteerEntity_volunteerId(int matchId,String volunteerId);

    Optional<MatchEntity> findByStatusAndVolunteerEntity_volunteerId(int status, String volunteerId);
}
