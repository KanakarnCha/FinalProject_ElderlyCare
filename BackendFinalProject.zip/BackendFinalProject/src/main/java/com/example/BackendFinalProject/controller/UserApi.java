package com.example.BackendFinalProject.controller;

import com.example.BackendFinalProject.Dto.ResToken;
import com.example.BackendFinalProject.Dto.ResMessage;
import com.example.BackendFinalProject.business.UserBusiness;
import com.example.BackendFinalProject.entity.UserEntity;
import com.example.BackendFinalProject.exception.BaseException;
import com.example.BackendFinalProject.model.LoginUser;
import com.example.BackendFinalProject.model.RegisterModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/control/api/user")
public class UserApi {
    @Autowired
    private UserBusiness userBusiness;

    @PostMapping("/register_user")
    public ResponseEntity<ResMessage> registerUser(@RequestBody RegisterModel registerModel) throws BaseException {
        ResMessage resRegister = new ResMessage();
        resRegister.setMessage(userBusiness.createUser(registerModel));
        return new ResponseEntity<ResMessage>(resRegister, HttpStatus.OK);
    }
    @PostMapping("/user/login")
    private ResponseEntity<ResToken> loginUser(@RequestBody LoginUser loginUser) throws BaseException {
        ResToken token = new ResToken();
        token.setToken(userBusiness.loginUser(loginUser));
        return new ResponseEntity<ResToken>(token,HttpStatus.OK);
    }
    @GetMapping("/profileUser")
    public ResponseEntity<UserEntity> showInfoUser(HttpServletRequest httpServletRequest){
        return new ResponseEntity<>(userBusiness.showInfoUser(httpServletRequest),HttpStatus.OK);
    }
}
