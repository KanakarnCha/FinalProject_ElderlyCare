package com.example.BackendFinalProject.repository;

import com.example.BackendFinalProject.entity.UserEntity;
import com.example.BackendFinalProject.entity.WorkEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WorkRepository extends JpaRepository<WorkEntity,Long> {
    List<WorkEntity> findAllByUserEntity(UserEntity user);


    List<WorkEntity> findAllByWorkStatus(int workStatus);

    boolean existsByUserEntity_userIdAndWorkStatus(String userid, int workStatus);


    Optional<WorkEntity> findByWorkStatusAndUserEntity_UserId(int workStatus,String userId);
}
