package com.example.BackendFinalProject.model;

import lombok.Data;

@Data
public class SearchSuccessWorkModel {
    int status;
}
