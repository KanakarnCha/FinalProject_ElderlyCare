package com.example.BackendFinalProject.Dto;

import lombok.Data;

@Data
public class ResToken {
    String token;
}
