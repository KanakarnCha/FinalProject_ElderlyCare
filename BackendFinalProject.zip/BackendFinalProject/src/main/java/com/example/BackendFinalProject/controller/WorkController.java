package com.example.BackendFinalProject.controller;

import com.example.BackendFinalProject.Dto.ResMessage;
import com.example.BackendFinalProject.entity.WorkEntity;
import com.example.BackendFinalProject.exception.BaseException;
import com.example.BackendFinalProject.model.AddWorkModel;
import com.example.BackendFinalProject.model.SearchOrder;
import com.example.BackendFinalProject.model.SearchSuccessWorkModel;
import com.example.BackendFinalProject.model.SearchWorkStatus;
import com.example.BackendFinalProject.repository.WorkRepository;
import com.example.BackendFinalProject.services.WorkService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import java.util.List;


@RestController
@RequestMapping("/control/api/user")
public class WorkController {
    @Autowired
    WorkService workService;
    @Autowired
    WorkRepository workRepository;
    @GetMapping("/getWork")
    public ResponseEntity<List<WorkEntity>> findAllWork(){
        return new ResponseEntity<List<WorkEntity>>(workService.findAllWork(), HttpStatus.OK);
    }

    //หาเเค่1ไอดีงานของคนเดียว
    @GetMapping("/toWork")
    public ResponseEntity<List<WorkEntity>> findUser(HttpServletRequest httpServletRequest) throws BaseException {
        return new ResponseEntity<>(workService.findUser(httpServletRequest),HttpStatus.OK);
    }




    @PostMapping("/WorkOrder")
    public ResponseEntity<ResMessage> createWork(HttpServletRequest request,@RequestBody AddWorkModel addWorkModel) throws BaseException {
        workService.createWork(request,addWorkModel);
        ResMessage resMessage = new ResMessage();
        resMessage.setMessage("Create Success");
        return new ResponseEntity<ResMessage>(resMessage,HttpStatus.OK);
    }

    @PostMapping("/findWorkNotMatch")
    public ResponseEntity<List<WorkEntity>> findWorkNotMatch(@RequestBody SearchSuccessWorkModel searchSuccessWorkModel){
        return new ResponseEntity<>(workService.findWorkNotMatch(searchSuccessWorkModel.getStatus()),HttpStatus.OK);
    }

    @PostMapping("/findOrder")
    public ResponseEntity<WorkEntity> findByIdOrder(@RequestBody SearchOrder searchOrder) throws BaseException {
        return new ResponseEntity<>(workService.findByIdOrder(searchOrder.getOrderId()),HttpStatus.OK);
    }

    @PostMapping("/findOrderInQ")
    public ResponseEntity<WorkEntity> findOrderInQ(HttpServletRequest request,@RequestBody SearchWorkStatus searchWorkStatus) throws BaseException {
        return new ResponseEntity<>(workService.findByWorkInQ(request,searchWorkStatus),HttpStatus.OK);
    }
}
