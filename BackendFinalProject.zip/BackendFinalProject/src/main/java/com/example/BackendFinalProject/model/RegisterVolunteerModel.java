package com.example.BackendFinalProject.model;

import lombok.Data;

@Data
public class RegisterVolunteerModel {
    private String volunteerUsername;
    private String volunteerFirstname;
    private String volunteerLastname;
    private String volunteerPhone;
    private String volunteerAddress;
    private String volunteerPassword;
    private String volunteerLineId;
}
