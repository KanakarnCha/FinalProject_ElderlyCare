package com.example.BackendFinalProject.Dto;

import lombok.Data;

@Data
public class ResMessage {
    String message;
}
