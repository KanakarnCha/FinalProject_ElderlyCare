package com.example.BackendFinalProject.controller;

import com.example.BackendFinalProject.Dto.ResToken;
import com.example.BackendFinalProject.Dto.ResMessage;
import com.example.BackendFinalProject.entity.VolunteerEntity;
import com.example.BackendFinalProject.exception.BaseException;
import com.example.BackendFinalProject.model.LoginVolunteerModel;
import com.example.BackendFinalProject.model.RegisterVolunteerModel;
import com.example.BackendFinalProject.repository.VolunteerRepository;
import com.example.BackendFinalProject.services.VolunteerServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.awt.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
@RequestMapping("api/volunteer")
public class VolunteerApi {

    @Autowired
    VolunteerRepository volunteerRepository;

    @Autowired
    VolunteerServices volunteerServices;
    @PostMapping("create")
    public ResponseEntity<ResMessage> createVolunteer(@RequestBody RegisterVolunteerModel registerVolunteerModel) throws BaseException {
        String message = volunteerServices.createVolunteer(registerVolunteerModel);
        ResMessage resMessage = new ResMessage();
        resMessage.setMessage(message);
        return new ResponseEntity<>(resMessage, HttpStatus.OK);
    }

    @PostMapping("login")
    public  ResponseEntity<ResToken> loginVolunteer(@RequestBody LoginVolunteerModel loginVolunteerModel) throws BaseException {
        String token = volunteerServices.login(loginVolunteerModel);
        ResToken resToken = new ResToken();
        resToken.setToken(token);
        return new ResponseEntity<>(resToken,HttpStatus.OK);
    }

    @GetMapping("findVolunteer")
    public ResponseEntity<VolunteerEntity> findVolunteer(HttpServletRequest httpServletRequest) throws BaseException {

        return new ResponseEntity<>(volunteerServices.findUser(httpServletRequest),HttpStatus.OK);
    }




    @PostMapping("/upload/image")
    public ResponseEntity<ResMessage> uploadImage(@RequestPart(name = "img") MultipartFile file) throws IOException {
        String fileName = file.getOriginalFilename();

        Path path = Paths.get("/FinalProject/Image", fileName);
        Files.copy(file.getInputStream(), path);
        ResMessage resMessage = new ResMessage();
        resMessage.setMessage(file.getContentType());
        return new ResponseEntity<>(resMessage,HttpStatus.OK);
    }
}
