package com.example.BackendFinalProject.model;

import lombok.Data;

@Data
public class RegisterModel {
    private String username;
    private String password;
    private String firstname;
    private String lastname;
    private String phoneNumber;
    private String profileImg;
    private String lineId;
}
