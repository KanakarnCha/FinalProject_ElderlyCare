package com.example.BackendFinalProject.model;

import lombok.Data;

@Data
public class AddWorkModel {
    private String goalLat;
    private String goalLong;
    private String startLat;
    private String startLong;
    private String workDescription;
    private String workStatus;
}
