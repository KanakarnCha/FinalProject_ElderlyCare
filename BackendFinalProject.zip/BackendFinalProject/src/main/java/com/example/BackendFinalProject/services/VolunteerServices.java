package com.example.BackendFinalProject.services;

import com.example.BackendFinalProject.entity.UserEntity;
import com.example.BackendFinalProject.entity.VolunteerEntity;
import com.example.BackendFinalProject.exception.BaseException;
import com.example.BackendFinalProject.exception.UserException;
import com.example.BackendFinalProject.model.LoginVolunteerModel;
import com.example.BackendFinalProject.model.RegisterVolunteerModel;
import com.example.BackendFinalProject.repository.VolunteerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;
import java.util.Optional;
@Service
public class VolunteerServices{
    @Autowired
    VolunteerRepository volunteerRepository;
    @Autowired
    JwtService jwtService;
    public final PasswordEncoder passwordEncoder;

    public VolunteerServices(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }


    public String createVolunteer(RegisterVolunteerModel registerVolunteerModel) throws BaseException {
        if (volunteerRepository.existsByVolunteerUsername(registerVolunteerModel.getVolunteerUsername())){
            throw UserException.failError();
        }
        VolunteerEntity volunteerEntity = new VolunteerEntity();
        volunteerEntity.setVolunteerUsername(registerVolunteerModel.getVolunteerUsername());
        volunteerEntity.setVolunteerPassword(passwordEncoder.encode(registerVolunteerModel.getVolunteerPassword()));
        volunteerEntity.setVolunteerLastname(registerVolunteerModel.getVolunteerLastname());
        volunteerEntity.setVolunteerFirstname(registerVolunteerModel.getVolunteerFirstname());
        volunteerEntity.setVolunteerPhone(registerVolunteerModel.getVolunteerPhone());
        volunteerEntity.setVolunteerAddress(registerVolunteerModel.getVolunteerAddress());
        volunteerEntity.setVolunteerLineId(registerVolunteerModel.getVolunteerLineId());
        volunteerRepository.save(volunteerEntity);
        return "Success";
    }
    public String login(LoginVolunteerModel loginVolunteerModel) throws BaseException {
        if (loginVolunteerModel.getVolunteerUsername() == null || Objects.equals(loginVolunteerModel.getVolunteerUsername(), "")){
            throw UserException.failError();
        }
        if (loginVolunteerModel.getVolunteerPassword() == null || Objects.equals(loginVolunteerModel.getVolunteerPassword(), "")){
            throw UserException.failError();
        }
        if (volunteerRepository.findByVolunteerUsername(loginVolunteerModel.getVolunteerUsername()).isEmpty()){
            throw UserException.failError();
        }
        Optional<VolunteerEntity> userEntity = volunteerRepository.findByVolunteerUsername(loginVolunteerModel.getVolunteerUsername());
        VolunteerEntity user  = userEntity.get();
        if (!passwordEncoder.matches(loginVolunteerModel.getVolunteerPassword(),user.getVolunteerPassword())){
            throw UserException.failError();
        }
        return jwtService.createToken(user.getVolunteerId());
    }


    public VolunteerEntity findUser(HttpServletRequest httpServletRequest) throws BaseException {
        String token  = jwtService.getToken(httpServletRequest);
        Optional<VolunteerEntity> volunteer = volunteerRepository.findById(token);
        if (volunteer.isEmpty()){
            throw UserException.failError();
        }else{
            VolunteerEntity user = volunteer.get();
            return user;
        }

    }
}
