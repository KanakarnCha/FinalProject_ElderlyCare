package com.example.BackendFinalProject.services;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.example.BackendFinalProject.entity.UserEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.Calendar;
import java.util.Date;

@Service
public class JwtService {
    private final String  secret = "secret";
    private final String  issuer = "issuer";
    public Algorithm algorithm(){
        return Algorithm.HMAC256(secret);
    }

    public String createToken(String id){
//        Calendar calendar = Calendar.getInstance();
//        calendar.add(Calendar.MINUTE, 60);
//        Date expiresAt = calendar.getTime();
        return  JWT.create()
                    .withClaim("principal", id)
                    .withClaim("role","user")
                    .withIssuer(issuer)
                 //   .withExpiresAt(expiresAt)
                    .sign(algorithm());

    }
    public DecodedJWT verifyToken(String token){
       try {
           return  JWT.require(algorithm())
                   .withIssuer(issuer)
                   .build().verify(token);
       }catch (Exception e){
           return null;
       }

    }
    public String getToken(HttpServletRequest request){
        String authorization = request.getHeader("Authorization");
        String token = authorization.substring(7,authorization.length());
        DecodedJWT tokenDecoded = verifyToken(token);
        String principal = String.valueOf(tokenDecoded.getClaim("principal"));
        String result = principal.replaceAll("^\"|\"$", "");
        return result;
    }

}
