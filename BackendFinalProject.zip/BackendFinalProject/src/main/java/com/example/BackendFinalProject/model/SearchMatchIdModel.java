package com.example.BackendFinalProject.model;

import lombok.Data;

@Data
public class SearchMatchIdModel {
     int matchId;
}
