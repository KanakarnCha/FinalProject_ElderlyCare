package com.example.elderlyapplication.network


import com.example.elderlyapplication.model.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create
import retrofit2.http.*
import java.util.*

interface RetrofitService {
    @POST("user/register_user")
    fun createUser(@Body registerModel: RegisterModel): Call<MessageRegModel>

    @POST("user/user/login")
    fun loginUser(@Body loginModel: LoginModel): Call<LoginToken>

    @POST("user/WorkOrder")
    fun createWork(@Header("Authorization") token:String,@Body addWorkModel: AddWorkModel ): Call<CreateResponse>

    @POST("showWorkSuccess")
    fun searchSuccessWork(@Header("Authorization") token:String,@Body searchModel: SearchModelSuccess ): Call<List<ResWorkSuccessModel>>
    @GET("user/profileUser")
    fun getInfoUser(@Header("Authorization") token:String): Call<ResInfoUser>
    @POST("findActiveMatch")
    fun showActiveMatch(@Header("Authorization") token:String,@Body searchModel: SearchModelSuccess ): Call<List<ResWorkSuccessModel>>

    @POST("userChangeStatusSuccess")
    fun userChangeStatusSuccess(@Header("Authorization") token:String,@Body searchMatchIdModel: SearchMatchIdModel):Call<CreateResponse>

    @POST("user/findOrderInQ")
    fun findOrderInQ(@Header("Authorization") token:String,@Body searchWorkStatus: SearchWorkStatus):Call<ResWorkEntity>

    companion object {

        private const val BaseURL = "http://192.168.1.33:8080/control/api/"
        private var retrofitService: RetrofitService? = null
        fun getInstance(): RetrofitService {

            val logging = HttpLoggingInterceptor()
            logging.level = (HttpLoggingInterceptor.Level.BODY)
            val client = OkHttpClient.Builder()
            client.addInterceptor(logging)
            if (retrofitService == null) {
                val retrofit = Retrofit.Builder()
                    .baseUrl(BaseURL)
                    .client(client.build())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                retrofitService = retrofit.create(RetrofitService::class.java)
            }
            return retrofitService!!
        }
    }
}