package com.example.elderlyapplication.model

data class ResInfoUser(
    val userFirstname: String,
    val userId: String,
    val userLastname: String,
    val userPassword: String,
    val userPhone: String,
    val userStatus: Int,
    val userProfileImg: Any,
    val userUsername: String,
    val lineId:String
)