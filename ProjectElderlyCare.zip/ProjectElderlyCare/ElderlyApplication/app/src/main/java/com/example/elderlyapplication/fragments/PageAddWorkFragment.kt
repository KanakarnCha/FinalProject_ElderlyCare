package com.example.elderlyapplication.fragments


import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.os.Binder
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.fragment.app.setFragmentResultListener
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.lifecycle.get
import androidx.navigation.fragment.findNavController
import com.example.elderlyapplication.R
import com.example.elderlyapplication.databinding.FragmentPageAddWorkBinding
import com.example.elderlyapplication.model.AddWorkModel
import com.example.elderlyapplication.network.RetrofitService
import com.example.elderlyapplication.repository.MainRepository
import com.example.elderlyapplication.session.TokenManager
import com.example.elderlyapplication.viewmodel.MainViewModel
import com.example.elderlyapplication.viewmodel.MapFgViewModel
import com.example.elderlyapplication.viewmodel.MapServiceViewModel
import com.example.elderlyapplication.viewmodelfactory.FragmentViewModelFactory
import com.example.elderlyapplication.viewmodelfactory.MainViewModelFactory
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.util.*


class PageAddWorkFragment : Fragment() {
    lateinit var btnGetLocationDestination: ImageButton
    lateinit var btnGetLocation: ImageButton
    lateinit var etDescription: EditText
    lateinit var btnSubmitAddWork: Button
    lateinit var mapServiceViewModel: MapServiceViewModel
    lateinit var mapFgViewModel: MapFgViewModel
    lateinit var tvDestination: TextView
    lateinit var txtAddress:TextView
    lateinit var goalLat: String
    lateinit var goalLong: String
    lateinit var startLat: String
    lateinit var startLong: String
    lateinit var description: String
    private lateinit var mainViewModel: MainViewModel
    lateinit var tokenManager: TokenManager
    lateinit var binder: FragmentPageAddWorkBinding
    private val retrofitService = RetrofitService.getInstance()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binder = FragmentPageAddWorkBinding.inflate(layoutInflater, container, false)
        // Inflate the layout for this fragment
        return binder.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        mapServiceViewModel = MapServiceViewModel()
        btnGetLocationDestination = view.findViewById(R.id.btnGetLocationDestination)
        btnGetLocation = view.findViewById(R.id.btnGetLocation)
        etDescription = view.findViewById(R.id.etDescription)
        btnSubmitAddWork = view.findViewById(R.id.btnSubmitAddWork)
        tvDestination = view.findViewById(R.id.tvDestination)
        txtAddress = view.findViewById(R.id.txtAddress)
        tokenManager = TokenManager()

        mapFgViewModel =
            ViewModelProvider(this, FragmentViewModelFactory()).get(MapFgViewModel::class.java)
        //แสดงสถานที่
        if (arguments?.getDouble("lat") != null || arguments?.getDouble("long") != null || arguments?.getDouble(
                "city"
            ) != null
        ) {
            tvDestination.text = arguments?.getString("city")

        }
        btnGetLocationDestination.setOnClickListener {
            findNavController().popBackStack()
            findNavController().navigate(R.id.mapDestinationFragment)
        }
        btnGetLocation.setOnClickListener {
            currentLocation(view)
        }




        btnSubmitAddWork.setOnClickListener {
            try {
                goalLat = arguments?.getDouble("lat").toString()
                goalLong = arguments?.getDouble("long").toString()
                description = etDescription.text.toString()
               val addWorkModel = AddWorkModel(
                   goalLat = goalLat,
                   goalLong = goalLong,
                   startLat = startLat,
                   startLong = startLong,
                   workDescription = description,
                    workStatus = 0)
                if (goalLat ==null||goalLong == null ||startLat == null ||  startLong == null ||description==null ){
                    Toast.makeText(view.context, "ERROR", Toast.LENGTH_SHORT).show()
                }else{
                    val builder = AlertDialog.Builder(view.context)
                    builder.setMessage("ต้องการแอดงาน")
                        .setTitle("กรุณากดยืนยัน")
                        .setPositiveButton("ตกลง",
                            DialogInterface.OnClickListener { dialog, id ->
                                mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
                                mainViewModel.createWork("Bearer "+tokenManager.getToken(view.context),addWorkModel)
                                println(addWorkModel)
                                findNavController().popBackStack()
                                Toast.makeText(view.context, "สำเร็จ", Toast.LENGTH_SHORT).show()
                            })
                        .setNegativeButton("ยกเลิก",
                            DialogInterface.OnClickListener { dialog, id ->

                            })
                        .setCancelable(true)
                    builder.create()
                    builder.show()
                }
            }catch (e:Exception){
                val builder = AlertDialog.Builder(view.context)
                builder.setMessage("กรุณากรอกข้อมูลให้ครบ")
                    .setTitle("ล้มเหลว")
                    .setPositiveButton("ตกลง",
                        DialogInterface.OnClickListener { dialog, id ->
                            // START THE GAME!
                        })
                builder.create()
                builder.show()
            }


        }


    }

    private fun currentLocation(view: View) {
        lateinit var current: Location
        var fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(view.context)

        if (ActivityCompat.checkSelfPermission(
                view.context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                view.context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                view.context as Activity,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                101
            )
            return
        } else {
            fusedLocationProviderClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    current = location
                    startLat = current.latitude.toString()
                    startLong = current.longitude.toString()
                    getCityName(view,startLat.toDouble(), current.longitude)
                    println("${startLat.toDouble()}" + "Check" + current.latitude)
                } else {
                    Toast.makeText(view.context, "Null", Toast.LENGTH_SHORT).show()
                }
            }

        }
    }
    private fun getCityName(view: View,lat: Double, long: Double) {
        val geoCoder = Geocoder(view.context, Locale.getDefault())
        val address = geoCoder.getFromLocation(lat, long, 1)
        val allAddress = address[0].getAddressLine(0)
        txtAddress.text = allAddress
    }
}


