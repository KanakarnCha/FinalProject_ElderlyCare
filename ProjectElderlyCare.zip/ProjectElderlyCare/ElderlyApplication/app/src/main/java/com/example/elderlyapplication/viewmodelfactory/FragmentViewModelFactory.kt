package com.example.elderlyapplication.viewmodelfactory;

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.elderlyapplication.viewmodel.MapFgViewModel

public class FragmentViewModelFactory:ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MapFgViewModel::class.java)){
            return MapFgViewModel() as T
        }else{
            throw  IllegalArgumentException("Unknow View Modle")
        }

    }
}
