package com.example.elderlyapplication.fragments

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.denzcoskun.imageslider.ImageSlider
import com.denzcoskun.imageslider.models.SlideModel
import com.example.elderlyapplication.MainActivityFragment
import com.example.elderlyapplication.R
import com.example.elderlyapplication.databinding.FragmentHomeBinding
import com.example.elderlyapplication.model.SearchWorkStatus
import com.example.elderlyapplication.network.RetrofitService
import com.example.elderlyapplication.repository.MainRepository
import com.example.elderlyapplication.session.TokenManager
import com.example.elderlyapplication.viewmodel.MainViewModel
import com.example.elderlyapplication.viewmodelfactory.MainViewModelFactory

class HomeFragment : Fragment() {
    val tokenManager = TokenManager()
    lateinit var binding:FragmentHomeBinding
    lateinit var mainViewModel: MainViewModel
    val retrofitService = RetrofitService.getInstance()
    private lateinit var imageSlider:ImageSlider
    lateinit var btnAddWork:Button
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(layoutInflater,container, false)
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        loadData(view)
        imageSlider = view.findViewById<ImageSlider>(R.id.imgSlider)
        btnAddWork = view.findViewById<Button>(R.id.btnAddWork)
        var tokenManager = TokenManager()
        if (tokenManager.getToken(view.context) == ""){
            findNavController().popBackStack()
        }
        val imageList = ArrayList<SlideModel>()
        imageList.add(SlideModel("http://2.bp.blogspot.com/-lCBvaRvYgU0/T9coZ8ygrqI/AAAAAAAAAro/eIWhLcgTTEM/s1600/volunteer-connex-header.png"))
        imageList.add(SlideModel("https://allwellhealthcare.com/wp-content/uploads/2020/03/disable-injury-senior-asian-man-try-stand-up-with-walking-cane.jpg"))
        imageSlider.setImageList(imageList)
        imageSlider.startSliding(1000)
        println(tokenManager.getToken(view.context))
        btnAddWork.setOnClickListener {
            findNavController().navigate(R.id.pageAddWorkFragment)
        }
    }
    private fun loadData(view: View){
        mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
        mainViewModel.resInfoUser.observe(viewLifecycleOwner){
            if (it.userStatus == 1){
                binding.btnAddWork.visibility = View.GONE
                binding.cardViewText.visibility = View.VISIBLE
                mainViewModel.resWorkEntity.observe(viewLifecycleOwner){
                        binding.tvStatusWork.text = "กำลังรอแมทช์"
                    binding.tvStatusWork.setTextColor(Color.rgb	(255,215,0))
                }
                mainViewModel.resErrorMessage.observe(viewLifecycleOwner){
                    binding.tvStatusWork.text = "กำลังแมทช์"
                    binding.tvStatusWork.setTextColor(Color.rgb(51,102,0))
                }
            }else{
                binding.cardViewText.visibility = View.GONE
                binding.btnAddWork.visibility = View.VISIBLE
            }
        }
        mainViewModel.getInfoUser("Bearer "+tokenManager.getToken(view.context))
        val searchWorkStatus = SearchWorkStatus(
            workStatus = 0
        )
        mainViewModel.findOrderInQ("Bearer "+tokenManager.getToken(view.context),searchWorkStatus)

    }
}