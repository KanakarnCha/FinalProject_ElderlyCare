package com.example.elderlyapplication.model

data class ResWorkSuccessModel(
    val matchId: Int,
    val status: Int,
    val timeStamp: String,
    val userId: String,
    val volunteerEntity: VolunteerEntity,
    val workEntity: WorkEntity
)
data class WorkEntity(
    val goalLat: String,
    val goalLong: String,
    val startLat: String,
    val startLong: String,
    val userEntity: UserEntity,
    val workDescription: String,
    val workOrderId: Int,
    val workStatus: Int
)
data class UserEntity(
    val userFirstname: String,
    val userId: String,
    val userLastname: String,
    val userPassword: String,
    val userPhone: String,
    val userProfileImg: Any,
    val userUsername: String,
    val lineId:String
)
data class VolunteerEntity(
    val volunteerAddress: String,
    val volunteerFirstname: String,
    val volunteerId: String,
    val volunteerImg: Any,
    val volunteerLastname: String,
    val volunteerPassword: String,
    val volunteerPhone: String,
    val volunteerUsername: String,
    val volunteerLineId:String
)

data class SearchModelSuccess(
    val status:Int
)

data class ResWorkEntity(
    val goalLat: String,
    val goalLong: String,
    val startLat: String,
    val startLong: String,
    val userEntity: UserEntity,
    val workDescription: String,
    val workOrderId: Int,
    val workStatus: Int
)