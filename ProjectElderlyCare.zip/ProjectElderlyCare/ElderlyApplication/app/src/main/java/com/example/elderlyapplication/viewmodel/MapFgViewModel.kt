package com.example.elderlyapplication.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.elderlyapplication.model.LoginToken
import com.google.android.gms.maps.model.LatLng

class MapFgViewModel:ViewModel() {
    var longitude:MutableLiveData<Double> = MutableLiveData<Double>()
    var latitude:MutableLiveData<Double> = MutableLiveData<Double>()
    fun setLatLong(latLng: Double,longitude: Double){
        this.longitude.postValue(longitude)
        this.latitude.postValue(latLng)
    }
}