package com.example.elderlyapplication.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.elderlyapplication.adapter.WorkRecyclerView
import com.example.elderlyapplication.databinding.FragmentWorkBinding
import com.example.elderlyapplication.model.ResModel
import com.example.elderlyapplication.model.SearchModelSuccess
import com.example.elderlyapplication.network.RetrofitService
import com.example.elderlyapplication.repository.MainRepository
import com.example.elderlyapplication.session.TokenManager
import com.example.elderlyapplication.viewmodel.MainViewModel
import com.example.elderlyapplication.viewmodelfactory.MainViewModelFactory


class WorkFragment : Fragment() {
    lateinit var binding: FragmentWorkBinding
    lateinit var recyclerView: WorkRecyclerView
    lateinit var workModel: List<ResModel>
    private lateinit var mainViewModel: MainViewModel
     var tokenManager = TokenManager()
    var retrofitService = RetrofitService.getInstance()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentWorkBinding.inflate(layoutInflater,container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val layoutManager:RecyclerView.LayoutManager = LinearLayoutManager(view.context)
        binding.recycleWorkAll.layoutManager = layoutManager
        binding.swipeRefresh.setOnRefreshListener {
            loadData()
            binding.swipeRefresh.isRefreshing = false
        }
        loadData()
    }


    private fun loadData(){
        mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
        val searchModelSuccess = SearchModelSuccess(
            2
        )
        mainViewModel.searchSuccessWork("Bearer "+tokenManager.getToken(binding.root.context),searchModelSuccess)
        mainViewModel.resWorkSuccessModel.observe(viewLifecycleOwner) {
            recyclerView = WorkRecyclerView(it)
            binding.recycleWorkAll.adapter = recyclerView
        }
    }



}