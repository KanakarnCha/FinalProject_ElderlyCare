package com.example.elderlyapplication

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.elderlyapplication.model.LoginModel
import com.example.elderlyapplication.network.RetrofitService
import com.example.elderlyapplication.repository.MainRepository
import com.example.elderlyapplication.session.TokenManager
import com.example.elderlyapplication.viewmodel.MainViewModel
import com.example.elderlyapplication.viewmodelfactory.MainViewModelFactory

class PageLogin : AppCompatActivity() {
    private lateinit var mainViewModel: MainViewModel
    private var retrofitService = RetrofitService.getInstance()
    lateinit var etUserNameLogin: EditText
    lateinit var etPasswordLogin: EditText
    lateinit var btnLogin: Button
    private var tokenManager = TokenManager()
    @SuppressLint("CommitPrefEdits")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page_login)
        etUserNameLogin = findViewById(R.id.etUserNameLogin)
        etPasswordLogin = findViewById(R.id.etPasswordLogin)
        btnLogin = findViewById(R.id.btnLogin)
        if (tokenManager.getToken(this) != ""){
            val intent = Intent(this@PageLogin, MainActivityFragment::class.java)
            startActivity(intent)
            finish()
        }
        btnLogin.setOnClickListener {

            val loginModel =
                LoginModel(etUserNameLogin.text.toString(), etPasswordLogin.text.toString())
            mainViewModel =
                ViewModelProvider(this, MainViewModelFactory(MainRepository(retrofitService))).get(
                    MainViewModel::class.java
                )
                mainViewModel.loginUser(loginModel)
                mainViewModel.token.observe(this){
                    if (it.token == null){
                        Toast.makeText(this@PageLogin, "Fail To login", Toast.LENGTH_SHORT).show()
                        finish()
                        startActivity(intent)
                    }else{
                        tokenManager.setToken(this@PageLogin,it.token.toString())
                        Toast.makeText(this@PageLogin, "Login Success", Toast.LENGTH_SHORT).show()
                        finish()
                        val intent = Intent(this@PageLogin, MainActivityFragment::class.java)
                        startActivity(intent)
                    }
                }
      

        }
    }



}