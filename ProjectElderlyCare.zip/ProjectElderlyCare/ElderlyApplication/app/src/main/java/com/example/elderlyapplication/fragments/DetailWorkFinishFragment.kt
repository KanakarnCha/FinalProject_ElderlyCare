package com.example.elderlyapplication.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.navigation.fragment.findNavController
import com.example.elderlyapplication.R
import com.example.elderlyapplication.databinding.FragmentDetailWorkFinishBinding
import com.example.elderlyapplication.databinding.FragmentWorkBinding
import kotlinx.coroutines.NonDisposableHandle.parent


class DetailWorkFinishFragment : Fragment() {
    lateinit var binding:FragmentDetailWorkFinishBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentDetailWorkFinishBinding.inflate(layoutInflater,container, false)
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val tv = view.findViewById<TextView>(R.id.testText)
        val nameVolunteer = arguments?.getString("nameVolunteer")
        val phoneNumber = arguments?.getString("phoneNumber")
        val goalCity = arguments?.getString("goalCity")
        val startCity = arguments?.getString("startCity")
        binding.tvName.text = nameVolunteer
        binding.tvPhoneVolunteer.text = phoneNumber
        binding.tvStartAddress.text = startCity
        binding.tvGoalAddress.text = goalCity
        binding.btnBack.setOnClickListener {
            findNavController().popBackStack()
        }
    }
}