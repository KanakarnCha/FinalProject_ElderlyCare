package com.example.elderlyapplication.fragments

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.sax.RootElement
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.annotation.Size
import androidx.core.app.ActivityCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.viewbinding.ViewBinding
import com.example.elderlyapplication.R
import com.example.elderlyapplication.databinding.FragmentWorkActiveBinding
import com.example.elderlyapplication.databinding.ShowMessageActiveNullBinding
import com.example.elderlyapplication.model.SearchMatchIdModel
import com.example.elderlyapplication.model.SearchModelSuccess

import com.example.elderlyapplication.network.RetrofitService
import com.example.elderlyapplication.repository.MainRepository
import com.example.elderlyapplication.session.TokenManager
import com.example.elderlyapplication.viewmodel.MainViewModel
import com.example.elderlyapplication.viewmodelfactory.MainViewModelFactory
import okhttp3.internal.wait
import java.util.logging.Handler
import kotlin.properties.Delegates

class WorkActiveFragment : Fragment() {
    lateinit var mainViewModel: MainViewModel
    var retrofitService = RetrofitService.getInstance()
    var tokenManager = TokenManager()
    private lateinit var binding:ViewBinding;
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentWorkActiveBinding.inflate(layoutInflater,container,false)
        loadData(binding.root)


        return binding.root


        // Inflate the layout for this fragment

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        checkPermissions()
    }

    private fun loadData(view: View){
        val searchModelSuccess = SearchModelSuccess(
            1
        )
        mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
        mainViewModel.showActiveMatch("Bearer "+tokenManager.getToken(binding.root.context),searchModelSuccess)
        mainViewModel.resWorkActive.observe(viewLifecycleOwner) {
            if (it.isNotEmpty()){
                (binding as FragmentWorkActiveBinding).rly1.visibility  = View.VISIBLE
                (binding as FragmentWorkActiveBinding).tvLabelText.visibility = View.GONE
                (binding as FragmentWorkActiveBinding).tvOrder.text = it.get(0).workEntity.workOrderId.toString()
                (binding as FragmentWorkActiveBinding).tvName.text = it.get(0).volunteerEntity.volunteerFirstname +" "+ it.get(0).volunteerEntity.volunteerLastname
                (binding as FragmentWorkActiveBinding).tvNumber.text = it.get(0).volunteerEntity.volunteerPhone
                (binding as FragmentWorkActiveBinding).tvStartLocation.text = getCity(view,it.get(0).workEntity.startLat,it.get(0).workEntity.startLong)
                (binding as FragmentWorkActiveBinding).tvEndLocation.text = getCity(view,it.get(0).workEntity.goalLat,it.get(0).workEntity.goalLong)
                (binding as FragmentWorkActiveBinding).btnChat.setOnClickListener { h->
                    Toast.makeText(view.context, it.get(0).timeStamp.toString(), Toast.LENGTH_SHORT).show()

                    val callIntent = Intent(Intent.ACTION_CALL)
                    callIntent.setData(Uri.parse("tel:" + it.get(0).volunteerEntity.volunteerPhone));
                    startActivity(callIntent)
                }
                (binding as FragmentWorkActiveBinding).btnSuccess.setOnClickListener {
                    e->
                    val searchMatchIdModel = SearchMatchIdModel(
                        matchId = it.get(0).matchId
                    )
                    mainViewModel.userChangeStatusSuccess("Bearer "+tokenManager.getToken(binding.root.context),searchMatchIdModel)
                    refreshCurrentFragment()
                }
                (binding as FragmentWorkActiveBinding).btnChatLine.setOnClickListener {
                    i->
                    val intent = Intent()
                    intent.action = Intent.ACTION_VIEW
                    intent.data =
                        Uri.parse("https://line.me/ti/p/~${it.get(0).volunteerEntity.volunteerLineId}")
                    startActivity(intent)
                }

            }else{
                (binding as FragmentWorkActiveBinding).tvLabelText.visibility = View.VISIBLE
                (binding as FragmentWorkActiveBinding).rly1.visibility = View.GONE
                Toast.makeText(view.context, "ยังไม่มีงาน", Toast.LENGTH_SHORT).show()

            }

        }
    }

    fun getCity(view: View, lat:String, long:String):String{
        var geocoder = Geocoder((view.context))
        val addressList = geocoder.getFromLocation(lat.toDouble(),long.toDouble(),1)
        return addressList.get(0).getAddressLine(0).toString()
    }
    private fun checkPermissions(){
        if (ActivityCompat.checkSelfPermission(binding.root.context,
                Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
            activity?.let { ActivityCompat.requestPermissions(it, arrayOf(Manifest.permission.CALL_PHONE),101) }
        }
    }
    private fun refreshCurrentFragment(){
        val navController = findNavController();
        val id = navController.currentDestination?.id
        findNavController().popBackStack(id!!,true)
        navController.navigate(id)
    }
}