package com.example.elderlyapplication

import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.Button
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.elderlyapplication.viewmodel.MapFgViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var btnToRegister:Button
    private lateinit var btnToLogin:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnToRegister = findViewById(R.id.btnToRegister)
        btnToLogin = findViewById(R.id.btnToLogin)


    }

    override fun onResume() {
        super.onResume()
        btnToRegister.setOnClickListener {
            val changePageReg = Intent(this@MainActivity,PageRegister::class.java)
            startActivity(changePageReg)
            Toast.makeText(this@MainActivity, "Register", Toast.LENGTH_SHORT).show()
        }

        btnToLogin.setOnClickListener {
            val changePageReg = Intent(this@MainActivity,PageLogin::class.java)
            startActivity(changePageReg)
            Toast.makeText(this@MainActivity, "Login", Toast.LENGTH_SHORT).show()
        }
    }
}