package com.example.elderlyapplication.model

data class RegisterModel(
    var firstname: String,
    var lastname: String,
    var password: String,
    var phoneNumber: String,
    var username: String,
    var lineId:String
)

data class MessageRegModel(
    var massageReg: String?
)

