package com.example.elderlyapplication.viewmodel


import androidx.lifecycle.MutableLiveData

import androidx.lifecycle.ViewModel
import com.example.elderlyapplication.model.*
import com.example.elderlyapplication.repository.MainRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class MainViewModel(private val repository: MainRepository) : ViewModel() {
    val resWorkSuccessModel = MutableLiveData<List<ResWorkSuccessModel>>()
    val resInfoUser = MutableLiveData<ResInfoUser>()
    val resWorkActive = MutableLiveData<List<ResWorkSuccessModel>>()
    var token = MutableLiveData<LoginToken>()
    var messageRegModel = MutableLiveData<MessageRegModel>()
    var resErrorMessage = MutableLiveData<String>()
    var createResponse = MutableLiveData<CreateResponse>()
    var resWorkEntity = MutableLiveData<ResWorkEntity>()
    fun createUser(registerModel: RegisterModel) {
        val response = repository.createUser(registerModel)
        response.enqueue(object : Callback<MessageRegModel> {
            override fun onResponse(
                call: Call<MessageRegModel>,
                response: Response<MessageRegModel>
            ) {
                if (response.isSuccessful) {
                    messageRegModel.apply {
                        value = MessageRegModel(massageReg = "Success")
                    }
                } else {
                    messageRegModel.apply {
                        value = MessageRegModel(massageReg = null)
                    }
                }
            }

            override fun onFailure(call: Call<MessageRegModel>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })
    }


    fun loginUser(loginModel: LoginModel) {
        val response = repository.loginUser(loginModel)
        response.enqueue(object : Callback<LoginToken> {
            override fun onResponse(call: Call<LoginToken>, response: Response<LoginToken>) {
                if (response.isSuccessful) {
                    token.apply {
                        value = response.body()?.let { LoginToken(token = it.token) }
                    }
                } else {
                    token.apply {
                        value = LoginToken(token = null)
                    }
                }
            }

            override fun onFailure(call: Call<LoginToken>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })

    }

    fun createWork(token:String,addWorkModel: AddWorkModel) {
        val response = repository.createWork(token,addWorkModel)
        response.enqueue(object :Callback<CreateResponse>{
            override fun onResponse(
                call: Call<CreateResponse>,
                response: Response<CreateResponse>
            ) {
                if (response.isSuccessful){
                    println("SUCCESS UKK")
                }else{
                    println("WRONG")
                }

            }

            override fun onFailure(call: Call<CreateResponse>, t: Throwable) {
                println("ERROR")
            }
        })

    }

    fun searchSuccessWork(token: String,searchModelSuccess: SearchModelSuccess){
        val response = repository.searchSuccessWork(token,searchModelSuccess)
        response.enqueue(object :Callback<List<ResWorkSuccessModel>>{
            override fun onResponse(
                call: Call<List<ResWorkSuccessModel>>,
                response: Response<List<ResWorkSuccessModel>>
            ) {
                if (response.isSuccessful){
                    resWorkSuccessModel.postValue(response.body())
                }else{
                    resErrorMessage.postValue("ไม่สำเร็จ")
                }
            }

            override fun onFailure(call: Call<List<ResWorkSuccessModel>>, t: Throwable) {
                resErrorMessage.postValue("เชื่อมต่อไม่ได้")
            }

        })
    }
    fun getInfoUser(token: String){

        val response = repository.getInfoUser(token)
        response.enqueue(object :Callback<ResInfoUser>{
            override fun onResponse(call: Call<ResInfoUser>, response: Response<ResInfoUser>) {
                if (response.isSuccessful){
                    resInfoUser.postValue(response.body())
                }else{
                    resErrorMessage.postValue("ไม่สำเร็จ")
                }

            }

            override fun onFailure(call: Call<ResInfoUser>, t: Throwable) {
                resErrorMessage.postValue("เชื่อมต่อไม่ได้")
            }
        })
    }
    fun showActiveMatch(token: String,searchModelSuccess: SearchModelSuccess){
        val response = repository.showActiveMatch(token,searchModelSuccess)
        response.enqueue(object :Callback<List<ResWorkSuccessModel>>{
            override fun onResponse(
                call: Call<List<ResWorkSuccessModel>>,
                response: Response<List<ResWorkSuccessModel>>
            ) {
                if (response.body() != null){
                    resWorkActive.postValue(response.body())
                }else{
                    resErrorMessage.postValue("ไม่สำเร็จ")
                }

            }

            override fun onFailure(call: Call<List<ResWorkSuccessModel>>, t: Throwable) {
                resErrorMessage.postValue("เชื่อมต่อไม่ได้")
            }
        })
    }
    fun userChangeStatusSuccess(token: String,searchMatchIdModel: SearchMatchIdModel){
        val response = repository.userChangeStatusSuccess(token,searchMatchIdModel)
        response.enqueue(object :Callback<CreateResponse>{
            override fun onResponse(
                call: Call<CreateResponse>,
                response: Response<CreateResponse>
            ) {
                if (response.isSuccessful){
                    createResponse.postValue(response.body())
                }else{
                    resErrorMessage.postValue("ไม่สำเร็จ")
                }
            }

            override fun onFailure(call: Call<CreateResponse>, t: Throwable) {
                resErrorMessage.postValue("ล้มเหลว")
            }
        })
    }

    fun findOrderInQ(token:String, searchWorkStatus: SearchWorkStatus){
        val response = repository.findOrderInQ(token,searchWorkStatus)
        response.enqueue(object :Callback<ResWorkEntity>{
            override fun onResponse(call: Call<ResWorkEntity>, response: Response<ResWorkEntity>) {
                if (response.isSuccessful){
                    resWorkEntity.postValue(response.body())
                }else{
                    resErrorMessage.postValue("ไม่พบ")
                }
            }

            override fun onFailure(call: Call<ResWorkEntity>, t: Throwable) {
                resErrorMessage.postValue("ไม่สามารถเชื่อมต่อ")
            }
        })
    }
}