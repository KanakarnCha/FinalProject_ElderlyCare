package com.example.elderlyapplication.model

data class AddWorkModel(
    val goalLat: String,
    val goalLong: String,
    val startLat: String,
    val startLong: String,
    val workDescription: String,
    val workStatus: Int
)
data class CreateResponse(
    val message:String
)

data class SearchMatchIdModel(
    val matchId:Int
)

data class ResModel(
    val volunteerName:String,
    val discretion:String
)
data class SearchWorkStatus(
    val workStatus:Int
)