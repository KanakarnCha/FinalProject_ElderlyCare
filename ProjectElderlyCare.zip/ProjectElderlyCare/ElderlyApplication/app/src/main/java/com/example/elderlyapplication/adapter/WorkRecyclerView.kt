package com.example.elderlyapplication.adapter

import android.annotation.SuppressLint
import android.location.Geocoder

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.elderlyapplication.R
import com.example.elderlyapplication.databinding.WorkmodelBinding
import com.example.elderlyapplication.model.ResWorkSuccessModel
import com.google.android.gms.maps.model.LatLng
import okhttp3.internal.wait

class WorkRecyclerView(var workData: List<ResWorkSuccessModel>) :
    RecyclerView.Adapter<WorkRecyclerView.ViewHolder>() {
    inner class ViewHolder(val binding: WorkmodelBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = WorkmodelBinding.inflate(LayoutInflater.from(parent.context),parent,false)

        return ViewHolder(binding)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        with(holder) {
            with(workData[position]) {
                binding.tvNameVolunteer.text = this.volunteerEntity.volunteerFirstname + " " + this.volunteerEntity.volunteerLastname
                binding.TvDiscWork.text = this.workEntity.workOrderId.toString()
                holder.itemView.setOnClickListener {
                        view ->
                    val bundle = bundleOf (
                        "nameVolunteer" to this.volunteerEntity.volunteerFirstname + " " +this.volunteerEntity.volunteerLastname,
                        "phoneNumber" to this.volunteerEntity.volunteerPhone,
                        "goalCity" to getCity(view.rootView,this.workEntity.goalLat,this.workEntity.goalLong),
                        "startCity" to getCity(view.rootView,this.workEntity.startLat,this.workEntity.startLong),
                    )

                    view.findNavController().navigate(R.id.detailWorkFinishFragment,bundle)
                }
            }
        }

    }

    override fun getItemCount(): Int {
        return workData.size
    }

    private fun getCity(view: View, lat:String, long:String):String{
        var geocoder = Geocoder((view.context))
        val addressList = geocoder.getFromLocation(lat.toDouble(),long.toDouble(),1)
        return addressList.get(0).getAddressLine(0).toString()
    }
}