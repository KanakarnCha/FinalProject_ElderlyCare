package com.example.elderlyapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.elderlyapplication.model.RegisterModel
import com.example.elderlyapplication.network.RetrofitService
import com.example.elderlyapplication.repository.MainRepository
import com.example.elderlyapplication.viewmodel.MainViewModel
import com.example.elderlyapplication.viewmodelfactory.MainViewModelFactory
import okhttp3.internal.http2.Http2Reader
import java.util.*
import kotlin.concurrent.schedule
import kotlin.math.log

class PageRegister : AppCompatActivity() {
    private lateinit var mainViewModel: MainViewModel
    private val retrofitService = RetrofitService.getInstance()
    private lateinit var etFirstName: EditText
    private lateinit var etLastName: EditText
    private lateinit var etUserName: EditText
    private lateinit var etPassword: EditText
    private lateinit var etPhoneNumber: EditText
    private lateinit var etLineId: EditText
    private lateinit var btnSubmitRegister:Button
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_page_register)
        etFirstName = findViewById<EditText>(R.id.etFirstName)
        etLastName = findViewById<EditText>(R.id.etLastName)
        etUserName = findViewById<EditText>(R.id.etUserName)
        etPassword = findViewById<EditText>(R.id.etPassword)
        etPhoneNumber = findViewById<EditText>(R.id.etPhoneNumber)
        etLineId = findViewById<EditText>(R.id.etLineId)
        btnSubmitRegister = findViewById(R.id.btnSubmitRegister)
        val registerModel = RegisterModel(
            firstname = etFirstName.text.toString(),
            lastname = etLastName.text.toString(),
            password = etPassword.text.toString(),
            phoneNumber = etPhoneNumber.text.toString(),
            username = etUserName.text.toString(),
            lineId = etLineId.text.toString()
        )

        btnSubmitRegister.setOnClickListener {
            mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)

            mainViewModel.createUser(registerModel)
            mainViewModel.messageRegModel.observe(this){
                if (it.massageReg == null){
                    Toast.makeText(this@PageRegister, "Register Fail", Toast.LENGTH_SHORT).show()
                    finish();
                    startActivity(intent);

                }else{
                    Toast.makeText(this@PageRegister, "Register Success", Toast.LENGTH_SHORT).show()
                    finish();
                    var intent = Intent(applicationContext, PageLogin::class.java)
                    startActivity(intent)

                }
            }
        }
    }
    }
