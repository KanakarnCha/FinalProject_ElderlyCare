package com.example.elderlyapplication.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.elderlyapplication.PageLogin
import com.example.elderlyapplication.R
import com.example.elderlyapplication.databinding.FragmentProfileBinding
import com.example.elderlyapplication.network.RetrofitService
import com.example.elderlyapplication.repository.MainRepository
import com.example.elderlyapplication.session.TokenManager
import com.example.elderlyapplication.viewmodel.MainViewModel
import com.example.elderlyapplication.viewmodelfactory.MainViewModelFactory

class ProfileFragment : Fragment() {
    lateinit var tokenManager: TokenManager
    lateinit var mainViewModel:MainViewModel
    lateinit var binding: FragmentProfileBinding
    var retrofitService = RetrofitService.getInstance()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentProfileBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        tokenManager = TokenManager()
        view.findViewById<Button>(R.id.btnLogout).setOnClickListener {
            tokenManager.clearToken(view.context)
            findNavController().popBackStack()
            var intent = Intent(view.context, PageLogin::class.java)
            startActivity(intent)
            activity?.finish()
        }
        mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
        mainViewModel.resInfoUser.observe(viewLifecycleOwner){
                binding.tvFirstName.text = it.userFirstname
                binding.tvLastName.text = it.userLastname
                binding.tvPhoneNumber.text = it.userPhone
               //Toast.makeText(view.context, it.userStatus.toString(), Toast.LENGTH_SHORT).show()
        }
        mainViewModel.resErrorMessage.observe(viewLifecycleOwner){
            Toast.makeText(view.context, it.toString(), Toast.LENGTH_SHORT).show()
        }
        mainViewModel.getInfoUser("Bearer "+tokenManager.getToken(view.context))
    }


}
