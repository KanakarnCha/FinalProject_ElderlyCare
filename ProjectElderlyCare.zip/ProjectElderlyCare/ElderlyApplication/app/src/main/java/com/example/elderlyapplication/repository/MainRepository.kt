package com.example.elderlyapplication.repository

import com.example.elderlyapplication.model.*
import com.example.elderlyapplication.network.RetrofitService
import retrofit2.http.Body

class MainRepository constructor(private val retrofitService: RetrofitService) {
    //เก็บ Rest Api Method จาก RetrofitServices
    fun createUser(registerModel: RegisterModel) = retrofitService.createUser(registerModel)
    fun loginUser(loginModel: LoginModel) = retrofitService.loginUser(loginModel)

    fun createWork(token:String,addWorkModel: AddWorkModel) = retrofitService.createWork(token,addWorkModel)

    fun searchSuccessWork(token:String,searchModelSuccess: SearchModelSuccess) = retrofitService.searchSuccessWork(token,searchModelSuccess)

    fun getInfoUser(token:String) = retrofitService.getInfoUser(token)

    fun showActiveMatch(token:String,searchModelSuccess: SearchModelSuccess) = retrofitService.showActiveMatch(token,searchModelSuccess)
    fun userChangeStatusSuccess(token:String,searchMatchIdModel: SearchMatchIdModel) = retrofitService.userChangeStatusSuccess(token,searchMatchIdModel)
    fun findOrderInQ(token:String, searchWorkStatus: SearchWorkStatus) = retrofitService.findOrderInQ(token,searchWorkStatus)
}