package com.example.elderlyapplication.viewmodel

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat.getSystemService
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.GoogleMap
import java.util.*

class MapServiceViewModel {
    lateinit var geocoder: Geocoder
    lateinit var address: Address
    fun searchCity(view: View, text: String?): Address? {
        geocoder = Geocoder((view.context))
        val addressList = geocoder.getFromLocationName(text, 3)
        try {
            if (addressList.isNotEmpty()) {
                address = addressList[0]
                return address

            } else {
                return null
            }

        } catch (e: Exception) {
            e.stackTrace
        }
        return null
    }

}




