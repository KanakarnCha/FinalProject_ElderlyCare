package com.example.elderlyapplication.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class LoginModel(

    val username: String ,
    val password: String
)
data class LoginToken(

    val token: String?
)
