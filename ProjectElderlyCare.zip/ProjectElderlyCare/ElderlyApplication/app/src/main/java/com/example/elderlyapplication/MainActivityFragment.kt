package com.example.elderlyapplication


import android.content.Context

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager

import androidx.appcompat.app.AlertDialog
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.elderlyapplication.session.TokenManager
import com.google.android.material.bottomnavigation.BottomNavigationView


class MainActivityFragment : AppCompatActivity() {
    private var tokenManager = TokenManager()
    private lateinit var navController: NavController
    private lateinit var navHostFragment: NavHostFragment
    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_fragment)
        if (tokenManager.getToken(applicationContext) == "") {
            finish()
        }

        bottomNavigationView = findViewById(R.id.btnNavView)
        navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController
        bottomNavigationView.setupWithNavController(navController)
        hideNavigationBar()
    }

    private fun hideNavigationBar(){
        navController.addOnDestinationChangedListener { _, destination, _ ->
            if(destination.id == R.id.pageAddWorkFragment||destination.id == R.id.mapDestinationFragment) {
                bottomNavigationView.visibility = View.GONE
            } else {
                bottomNavigationView.visibility = View.VISIBLE
            }
        }
    }
}