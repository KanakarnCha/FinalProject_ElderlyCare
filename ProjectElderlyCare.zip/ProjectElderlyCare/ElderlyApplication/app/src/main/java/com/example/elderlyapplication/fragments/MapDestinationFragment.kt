package com.example.elderlyapplication.fragments

import android.location.Address
import androidx.fragment.app.Fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.SearchView
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.setFragmentResult
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.fragment.findNavController
import com.example.elderlyapplication.BuildConfig
import com.example.elderlyapplication.R
import com.example.elderlyapplication.repository.MainRepository
import com.example.elderlyapplication.viewmodel.MainViewModel
import com.example.elderlyapplication.viewmodel.MapFgViewModel
import com.example.elderlyapplication.viewmodel.MapServiceViewModel
import com.example.elderlyapplication.viewmodelfactory.FragmentViewModelFactory
import com.example.elderlyapplication.viewmodelfactory.MainViewModelFactory
import com.google.android.gms.maps.*

import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.AutocompleteSessionToken
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.model.RectangularBounds
import com.google.android.libraries.places.api.model.TypeFilter
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsResponse
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import kotlin.properties.Delegates

class MapDestinationFragment : Fragment() {
    lateinit var mapServiceViewModel: MapServiceViewModel
    private lateinit var svMap: SearchView
    lateinit var mapFragment: SupportMapFragment
    private lateinit var btnAddLocation: Button
    lateinit var mapFgViewModel: MapFgViewModel
    lateinit var bundle: Bundle
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    lateinit var googleMap: Address
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_map_destination, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mapFragment = (childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?)!!
        mapServiceViewModel = MapServiceViewModel()
        btnAddLocation = view.findViewById<Button>(R.id.btnAddLocation)
        svMap = view.findViewById<SearchView>(R.id.svMap)

        mapFgViewModel =
            ViewModelProvider(this, FragmentViewModelFactory()).get(MapFgViewModel::class.java)

        searchView(view)
        btnAddLocation.setOnClickListener {
            try {
                val bundle = bundleOf(
                    "lat" to latitude,
                    "long" to longitude,
                    "city" to googleMap.getAddressLine(0)
                )
                findNavController().popBackStack()
                findNavController().navigate(R.id.pageAddWorkFragment, bundle)
            } catch (e: Exception) {
                Toast.makeText(view.context, "กรุณาเลือกตำเเหน่ง", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun searchView(view: View) {
        svMap.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                val location = svMap.query.toString()
                try {
                    googleMap = mapServiceViewModel.searchCity(view, location)!!
                        latitude = googleMap.latitude
                        longitude = googleMap.longitude
                        mapFgViewModel.setLatLong(latitude, longitude)
                        mapFragment.getMapAsync { it ->
                            it.clear()
                            val location = LatLng(latitude, longitude)
                            it.addMarker(
                                MarkerOptions().position(location).title(googleMap.featureName)
                            )
                            it.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 20f))

                        }
                }catch (e:Exception){
                    Toast.makeText(view.context, "ไม่พบสถานที่ กรุณากรอกใหม่", Toast.LENGTH_SHORT)
                        .show()
                }


                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }

        })

    }


}