package com.example.volunteerapplication.fragment

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.volunteerapplication.R
import com.example.volunteerapplication.databinding.FragmentActiveWorkBinding
import com.example.volunteerapplication.model.SearchMatchId
import com.example.volunteerapplication.model.SearchWorkModel
import com.example.volunteerapplication.network.RetrofitService
import com.example.volunteerapplication.repository.MainRepository
import com.example.volunteerapplication.session.TokenManager
import com.example.volunteerapplication.viewmodel.MainViewModel
import com.example.volunteerapplication.viewmodelFactory.MainViewModelFactory
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions


class ActiveWorkFragment : Fragment() {
    val tokenManager = TokenManager()
    lateinit var mainViewModel: MainViewModel
    val retrofitService = RetrofitService.getInstance()
    lateinit var binding: FragmentActiveWorkBinding
    lateinit var mapFragment: SupportMapFragment
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentActiveWorkBinding.inflate(layoutInflater, container, false)
        mapFragment  = (childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?)!!

        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        checkPermissions()
        loadData()

    }


    private fun loadData() {
        mainViewModel =
            ViewModelProvider(this, MainViewModelFactory(MainRepository(retrofitService))).get(
                MainViewModel::class.java
            )
        mainViewModel.resWorkMatchModelActive.observe(viewLifecycleOwner) {
            view?.visibility = View.VISIBLE
            binding.tvOrderNumber.text = it.matchId.toString()
            binding.tvCardName.text = it.workEntity.userEntity.userFirstname + it.workEntity.userEntity.userLastname
            binding.tvCardPhone.text = it.workEntity.userEntity.userPhone
            binding.tvCardStartLocation.text = getCity(binding.root,it.workEntity.startLat,it.workEntity.startLong)
            binding.tvCardEndLocation.text = getCity(binding.root,it.workEntity.goalLat,it.workEntity.goalLong)
            binding.tvCardDescription.text = it.workEntity.workDescription
            mapFragment.getMapAsync { view ->
                view.clear()
                val location1 = LatLng(it.workEntity.startLat.toDouble(), it.workEntity.startLong.toDouble())
                val location2 = LatLng(it.workEntity.goalLat.toDouble(), it.workEntity.goalLong.toDouble())
                view.addMarker(
                    MarkerOptions().position(location1).title("START"),


                )
                view.addMarker(
                    MarkerOptions().position(location2).title("END")

                )
                view.moveCamera(CameraUpdateFactory.newLatLngZoom(location1, 12f))

            }

            binding.btnCallPhone.setOnClickListener {
                e->

                val callIntent = Intent(Intent.ACTION_CALL)
                callIntent.setData(Uri.parse("tel:" + it.workEntity.userEntity.userPhone));
                startActivity(callIntent)
            }
            binding.btnSuccessWork.setOnClickListener { t->
                val searchMatchId = SearchMatchId(
                    matchId = it.matchId
                )
                mainViewModel.changeStatusSuccess("Bearer " + tokenManager.getToken(binding.root.context),searchMatchId)
                mainViewModel.resSuccessModel.observe(viewLifecycleOwner){
                    Toast.makeText(this.context, "Success"+it.message, Toast.LENGTH_SHORT).show()
                    refreshCurrentFragment()
                }
            }
            binding.btnChatLine.setOnClickListener {
                t->
                Toast.makeText(this.context, it.workEntity.userEntity.lineId, Toast.LENGTH_SHORT).show()
                val intent = Intent()
                intent.action = Intent.ACTION_VIEW
                intent.data =
                    Uri.parse("https://line.me/ti/p/~${it.workEntity.userEntity.lineId}")
               startActivity(intent)
            }
           // Toast.makeText(this.context, it.toString(), Toast.LENGTH_SHORT).show()
        }
        mainViewModel.resError.observe(viewLifecycleOwner) {
            view?.visibility = View.GONE
            Toast.makeText(this.context, it.toString(), Toast.LENGTH_SHORT).show()
        }
        val searchWorkModel = SearchWorkModel(
            status = 1
        )
        mainViewModel.findMatchOn(
            "Bearer " + tokenManager.getToken(binding.root.context),
            searchWorkModel
        )

    }

    private fun getCity(view: View, lat:String, long:String):String{
        var geocoder = Geocoder((view.context))
        val addressList = geocoder.getFromLocation(lat.toDouble(),long.toDouble(),1)
        return addressList.get(0).getAddressLine(0).toString()
    }

    private fun checkPermissions(){
        if (ActivityCompat.checkSelfPermission(binding.root.context,Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
            activity?.let { ActivityCompat.requestPermissions(it, arrayOf(Manifest.permission.CALL_PHONE),101) }
        }
    }

    private fun refreshCurrentFragment(){
        val navController = findNavController();
        val id = navController.currentDestination?.id
        findNavController().popBackStack(id!!,true)
        navController.navigate(id)
    }
}