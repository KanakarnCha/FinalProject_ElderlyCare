package com.example.volunteerapplication.viewmodelFactory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.volunteerapplication.repository.MainRepository
import com.example.volunteerapplication.viewmodel.MainViewModel

class MainViewModelFactory (private val repository: MainRepository):ViewModelProvider.Factory  {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if(modelClass.isAssignableFrom(MainViewModel::class.java)){
            return MainViewModel(this.repository) as T
        }else{
            throw IllegalArgumentException("ViewModel Not Found")
        }

    }
}