package com.example.volunteerapplication.repository

import com.example.volunteerapplication.model.*
import com.example.volunteerapplication.network.RetrofitService
import okhttp3.MultipartBody

class MainRepository constructor(private val retrofitService: RetrofitService) {
    fun createVolunteer(createVolunteerModel: CrateVolunteerModel) = retrofitService.createVolunteer(createVolunteerModel)
    fun loginVolunteer(loginModel: LoginModel) = retrofitService.loginVolunteer(loginModel)
    fun findVolunteerInfo(token:String) = retrofitService.findVolunteerInfo(token)
    fun findWorkNotMatch(searchWorkModel: SearchWorkModel) = retrofitService.findWorkNotMatch(searchWorkModel)

    fun findByIdOrder(searchOrder: SearchOrder) = retrofitService.findByIdOrder(searchOrder)
    fun matchingUser(token:String,orderWork: OrderWork) = retrofitService.matchingUser(token,orderWork)
    fun findMatchOn(token:String,searchWorkModel: SearchWorkModel)= retrofitService.findMatchOn(token,searchWorkModel)
    fun changeStatusSuccess(token:String,searchMatchId: SearchMatchId) = retrofitService.changeStatusSuccess(token,searchMatchId)
    fun getHistoryMatchSuccessAll(token: String,searchWorkModel: SearchWorkModel) = retrofitService.getHistoryMatchSuccessAll(token,searchWorkModel)
    fun saveImage(img: MultipartBody.Part) = retrofitService.saveImage(img)
}