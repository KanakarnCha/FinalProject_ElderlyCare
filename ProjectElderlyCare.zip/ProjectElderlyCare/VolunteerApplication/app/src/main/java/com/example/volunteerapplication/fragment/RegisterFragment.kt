package com.example.volunteerapplication.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.volunteerapplication.R
import com.example.volunteerapplication.databinding.FragmentRegisterBinding
import com.example.volunteerapplication.model.CrateVolunteerModel
import com.example.volunteerapplication.network.RetrofitService
import com.example.volunteerapplication.repository.MainRepository
import com.example.volunteerapplication.viewmodel.MainViewModel
import com.example.volunteerapplication.viewmodelFactory.MainViewModelFactory

class RegisterFragment : Fragment() {
    lateinit var mainViewModel: MainViewModel
    var retrofitService = RetrofitService.getInstance()
    lateinit var binding:FragmentRegisterBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRegisterBinding.inflate(layoutInflater, container, false)
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
            binding.btnSubmitRegister.setOnClickListener {
                loadData()
            }
    }

    fun loadData(){
        var createVolunteerModel = CrateVolunteerModel(
            volunteerFirstname = binding.etFirstName.text.toString(),
            volunteerLastname = binding.etLastName.text.toString(),
            volunteerUsername = binding.etUserName.text.toString(),
            volunteerPassword = binding.etPassword.text.toString(),
            volunteerPhone = binding.etPhoneNumber.text.toString(),
            volunteerLineId = binding.etLineId.text.toString(),
            volunteerAddress = "เร็วๆนี้"
        )
        mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
        mainViewModel.createVolunteer(createVolunteerModel)
        mainViewModel.resSuccessModel.observe(viewLifecycleOwner) {
            findNavController().popBackStack()
            findNavController().navigate(R.id.loginFragment)
            Toast.makeText(view?.context, "สำเร็จ", Toast.LENGTH_SHORT).show()
        }
        mainViewModel.resError.observe(viewLifecycleOwner){
            findNavController().popBackStack()
            findNavController().navigate(R.id.registerFragment)
            Toast.makeText(view?.context, "ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
        }
    }
}