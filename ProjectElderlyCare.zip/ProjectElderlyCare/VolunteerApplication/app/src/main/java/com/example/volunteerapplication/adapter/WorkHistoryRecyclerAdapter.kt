package com.example.volunteerapplication.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.volunteerapplication.databinding.CardHistoryModelBinding
import com.example.volunteerapplication.model.ResWorkHistoryModel

class WorkHistoryRecyclerAdapter(val dataWorkHistory: List<ResWorkHistoryModel>) :
    RecyclerView.Adapter<WorkHistoryRecyclerAdapter.ViewHolder>() {
    inner class ViewHolder(var binding: CardHistoryModelBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            CardHistoryModelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        with(holder) {
            with(dataWorkHistory[position]) {
                binding.TvDiscWork.text = this.workEntity.workOrderId.toString()
                binding.tvNameVolunteer.text = this.workEntity.userEntity.userFirstname + " " + this.workEntity.userEntity.userLastname

            }
        }
    }

    override fun getItemCount(): Int {
        return dataWorkHistory.size
    }
}