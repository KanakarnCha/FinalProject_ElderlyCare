package com.example.volunteerapplication.adapter

import android.annotation.SuppressLint
import android.location.Geocoder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.volunteerapplication.R
import com.example.volunteerapplication.databinding.CardWorkNotMatchModelBinding
import com.example.volunteerapplication.databinding.FragmentHomeBinding
import com.example.volunteerapplication.databinding.FragmentProfileBinding
import com.example.volunteerapplication.fragment.HomeFragment
import com.example.volunteerapplication.model.ResWorkNotMatchModel
import okhttp3.internal.wait

class WorkRecyclerAdapter(var workData: List<ResWorkNotMatchModel>) :
    RecyclerView.Adapter<WorkRecyclerAdapter.ViewHolder>() {
    inner class ViewHolder(var binding:CardWorkNotMatchModelBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = CardWorkNotMatchModelBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ViewHolder(binding)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        with(holder){
            with(workData[position]){
                    binding.tvOrderNumber.text = this.workOrderId.toString()
                    binding.tvCardName.text = this.userEntity.userFirstname +" "+ this.userEntity.userLastname
                    binding.tvCardPhone.text = this.userEntity.userPhone
                    binding.tvCardStartLocation.text = getCity(binding.root,this.startLat,this.startLong)
                    binding.tvCardEndLocation.text = getCity(binding.root,this.goalLat,this.goalLong)
                    holder.itemView.setOnClickListener {
                            view->
                        val bundle = bundleOf(
                            "workId" to this.workOrderId
                        )
                        view.findNavController().navigate(R.id.infoWorkFragment,bundle)
                    }


            }

        }
    }

    override fun getItemCount(): Int {
        return workData.size
    }

    private fun getCity(view: View, lat:String, long:String):String{
        var geocoder = Geocoder((view.context))
        val addressList = geocoder.getFromLocation(lat.toDouble(),long.toDouble(),1)
        return addressList.get(0).getAddressLine(0).toString()
    }
}