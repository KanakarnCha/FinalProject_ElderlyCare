package com.example.volunteerapplication.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.volunteerapplication.R
import com.example.volunteerapplication.adapter.WorkRecyclerAdapter
import com.example.volunteerapplication.databinding.FragmentHomeBinding
import com.example.volunteerapplication.model.ResWorkNotMatchModel
import com.example.volunteerapplication.model.SearchWorkModel
import com.example.volunteerapplication.model.UserEntity
import com.example.volunteerapplication.network.RetrofitService
import com.example.volunteerapplication.repository.MainRepository
import com.example.volunteerapplication.session.TokenManager
import com.example.volunteerapplication.viewmodel.MainViewModel
import com.example.volunteerapplication.viewmodelFactory.MainViewModelFactory

class HomeFragment : Fragment() {
    var tokenManager = TokenManager()
    lateinit var binding: FragmentHomeBinding
    lateinit var mainViewModel: MainViewModel
    lateinit var recyclerView:WorkRecyclerAdapter
    val retrofitService = RetrofitService.getInstance()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(layoutInflater, container, false)
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        checkStatus(view)
        val layoutManager:RecyclerView.LayoutManager = LinearLayoutManager(view.context)
        binding.recyclerViewWorkPageHome.layoutManager = layoutManager
        loadData(view)
    }

    private fun loadData(view: View) {
        val searchWorkModel = SearchWorkModel(
            0
        )
        mainViewModel= ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
        mainViewModel.findWorkNotMatch(searchWorkModel,view)
        mainViewModel.resWorkNotMatchModel.observe(viewLifecycleOwner){
                recyclerView = WorkRecyclerAdapter(it)
                binding.recyclerViewWorkPageHome.adapter = recyclerView
        }
        mainViewModel.resError.observe(viewLifecycleOwner){
            Toast.makeText(view.context, it.toString(), Toast.LENGTH_SHORT).show()
        }

    }

    private fun checkStatus(view: View){
            mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
            mainViewModel.resVolunteerInfo.observe(viewLifecycleOwner){
                    if (it.volunteerStatus == 0){
                        view.visibility = View.VISIBLE
                    }else{
                        view.visibility = View.GONE
                    }
            }
            mainViewModel.resError.observe(viewLifecycleOwner){
                Toast.makeText(view.context, it.toString(), Toast.LENGTH_SHORT).show()
            }
            mainViewModel.findVolunteerInfo("Bearer "+tokenManager.getToken(view.context))

    }

}