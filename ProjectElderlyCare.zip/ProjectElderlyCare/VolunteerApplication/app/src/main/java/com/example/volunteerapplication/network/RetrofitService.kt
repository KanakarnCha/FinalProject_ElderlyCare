package com.example.volunteerapplication.network

import com.example.volunteerapplication.model.*
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create
import retrofit2.http.*

interface RetrofitService {
    @POST("api/volunteer/create")
    fun createVolunteer(@Body createVolunteerModel: CrateVolunteerModel):Call<ResponseSuccessModel>
    @POST("api/volunteer/login")
    fun loginVolunteer(@Body loginModel: LoginModel):Call<ResTokenModel>

    @GET("api/volunteer/findVolunteer")
    fun findVolunteerInfo(@Header("Authorization") token:String):Call<ResVolunteerInfo>
    @POST("control/api/user/findWorkNotMatch")
    fun findWorkNotMatch(@Body searchWorkModel:SearchWorkModel):Call<List<ResWorkNotMatchModel>>
    @POST("control/api/user/findOrder")
    fun findByIdOrder(@Body searchOrder:SearchOrder):Call<ResWorkNotMatchModel>
    @POST("/control/api/matching")
    fun matchingUser(@Header("Authorization") token:String ,@Body orderWork:OrderWork):Call<ResWorkNotMatchModel>
    @POST("/control/api/findMatchVolunteer")
    fun findMatchOn(@Header("Authorization") token:String ,@Body searchWorkModel: SearchWorkModel):Call<ResWorkModel>
    @POST("/control/api/changeStatusSuccess")
    fun changeStatusSuccess(@Header("Authorization") token:String ,@Body searchMatchId: SearchMatchId):Call<ResponseSuccessModel>
    @POST("/control/api/findAllMatchSuccessVolunteer")
    fun getHistoryMatchSuccessAll(@Header("Authorization") token:String ,@Body searchWorkModel: SearchWorkModel):Call<List<ResWorkHistoryModel>>
    @Multipart
    @POST("/api/volunteer/upload/image")
    fun saveImage(@Part img:MultipartBody.Part):Call<String>

    companion object{
        const val BaseURL = "http://192.168.1.33:8080/"
        var retrofitService:RetrofitService? = null
        fun getInstance():RetrofitService{
            val logging = HttpLoggingInterceptor()
            logging.level = (HttpLoggingInterceptor.Level.BODY)
            val client = OkHttpClient.Builder()
            client.addInterceptor(logging)
            if (retrofitService == null){
                val retrofit = Retrofit.Builder()
                    .baseUrl(BaseURL)
                    .client(client.build())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                retrofitService = retrofit.create(RetrofitService::class.java)
            }
            return retrofitService!!
        }
    }
}