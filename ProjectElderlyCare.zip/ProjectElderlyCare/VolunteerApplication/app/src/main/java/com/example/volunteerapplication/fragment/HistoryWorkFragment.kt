package com.example.volunteerapplication.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.volunteerapplication.R
import com.example.volunteerapplication.adapter.WorkHistoryRecyclerAdapter
import com.example.volunteerapplication.databinding.FragmentHistoryWorkBinding
import com.example.volunteerapplication.model.SearchWorkModel
import com.example.volunteerapplication.network.RetrofitService
import com.example.volunteerapplication.repository.MainRepository
import com.example.volunteerapplication.session.TokenManager
import com.example.volunteerapplication.viewmodel.MainViewModel
import com.example.volunteerapplication.viewmodelFactory.MainViewModelFactory


class HistoryWorkFragment : Fragment() {
    val tokenManager = TokenManager()
    lateinit var binding: FragmentHistoryWorkBinding
    lateinit var mainViewModel: MainViewModel
    lateinit var recyclerView: WorkHistoryRecyclerAdapter
    val retrofitService = RetrofitService.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHistoryWorkBinding.inflate(layoutInflater, container, false)
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(view.context)
        binding.recyclerViewWorkHistoryPage.layoutManager = layoutManager
        loadDataHistory()
    }


    private fun loadDataHistory(){
        mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
        val searchWorkModel = SearchWorkModel(
            status = 2
        )
        mainViewModel.getHistoryMatchSuccessAll("Bearer " + tokenManager.getToken(binding.root.context),searchWorkModel)
        mainViewModel.resWorkHistoryModel.observe(viewLifecycleOwner){
            recyclerView = WorkHistoryRecyclerAdapter(it)
            binding.recyclerViewWorkHistoryPage.adapter = recyclerView
           // Toast.makeText(this.context, ""+it, Toast.LENGTH_SHORT).show()
        }

    }
}