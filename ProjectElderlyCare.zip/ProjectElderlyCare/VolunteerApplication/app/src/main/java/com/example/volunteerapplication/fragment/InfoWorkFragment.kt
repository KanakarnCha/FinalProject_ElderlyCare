package com.example.volunteerapplication.fragment

import android.location.Geocoder
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.volunteerapplication.R
import com.example.volunteerapplication.databinding.FragmentInfoWorkBinding
import com.example.volunteerapplication.model.OrderWork
import com.example.volunteerapplication.model.SearchOrder
import com.example.volunteerapplication.network.RetrofitService
import com.example.volunteerapplication.repository.MainRepository
import com.example.volunteerapplication.session.TokenManager
import com.example.volunteerapplication.viewmodel.MainViewModel
import com.example.volunteerapplication.viewmodelFactory.MainViewModelFactory


class InfoWorkFragment : Fragment() {
    lateinit var mainViewModel: MainViewModel
    val retrofitService = RetrofitService.getInstance()
    lateinit var binding:FragmentInfoWorkBinding
    var tokenManager = TokenManager()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentInfoWorkBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val workId = arguments?.getInt("workId")
        println(workId)
        loadData(view,workId!!)
    }


    private fun loadData(view: View,orderId:Int){
        val searchOrder =SearchOrder(
            orderId = orderId
        )
        mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
        mainViewModel.resWorkOrderIdModel.observe(viewLifecycleOwner){

                binding.tvOrderNumber.text = it.workOrderId.toString()
                binding.tvCardName.text = it.userEntity.userFirstname +" "+ it.userEntity.userLastname
                binding.tvCardPhone.text = it.userEntity.userPhone
                binding.tvCardStartLocation.text = getCity(binding.root,it.startLat,it.startLong)
                binding.tvCardEndLocation.text = getCity(binding.root,it.goalLat,it.goalLong)
                binding.tvCardDescription.text = it.workDescription
                binding.btnMatch.setOnClickListener {
                    view ->
                    val orderWork = OrderWork(
                        orderWork = it.workOrderId
                    )
                    mainViewModel.matchingUser("Bearer "+tokenManager.getToken(view.context)!!,orderWork)
                    mainViewModel.resWorkMatchModel.observe(viewLifecycleOwner){
                        Toast.makeText(view.context, "Success", Toast.LENGTH_SHORT).show()
                        findNavController().popBackStack()
                        refreshCurrentFragment()
                    }
                }

        }

        mainViewModel.resError.observe(viewLifecycleOwner){

            println(it)
        }
        mainViewModel.findByIdOrder(searchOrder)
    }


    private fun getCity(view: View, lat:String, long:String):String{
        var geocoder = Geocoder((view.context))
        val addressList = geocoder.getFromLocation(lat.toDouble(),long.toDouble(),1)
        return addressList.get(0).getAddressLine(0).toString()
    }
    private fun refreshCurrentFragment(){
        val navController = findNavController();
        val id = navController.currentDestination?.id
        findNavController().popBackStack(id!!,true)
        navController.navigate(id)
    }
}