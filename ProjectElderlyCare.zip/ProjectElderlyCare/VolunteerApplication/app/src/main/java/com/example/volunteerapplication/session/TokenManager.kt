package com.example.volunteerapplication.session

import android.content.Context
import android.content.SharedPreferences

class TokenManager {
    private val SHARED_PREF_NAME = "net.rouk1.SHARED_PREF_NAME"
    private val TOKEN_KEY = "net.rouk1.TOKEN_KEY"

    fun getToken(c: Context): String? {
        val prefs: SharedPreferences =
            c.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(TOKEN_KEY, "")
    }

    fun setToken(c: Context, token: String?) {
        val prefs: SharedPreferences = c.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        editor.putString(TOKEN_KEY, token)
        editor.apply()
    }

    fun clearToken(c: Context){
        val prefs: SharedPreferences = c.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        editor.clear()
        editor.apply()
    }
}