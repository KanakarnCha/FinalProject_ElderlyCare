package com.example.volunteerapplication.viewmodel

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.view.View
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.volunteerapplication.model.*
import com.example.volunteerapplication.repository.MainRepository
import com.google.android.gms.location.LocationServices

import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainViewModel(private val repository: MainRepository) : ViewModel() {
    var resTokenModel = MutableLiveData<ResTokenModel>()
    var resSuccessModel = MutableLiveData<ResponseSuccessModel>()
    var resVolunteerInfo = MutableLiveData<ResVolunteerInfo>()
    val resError = MutableLiveData<String>()
    val resWorkNotMatchModel = MutableLiveData<List<ResWorkNotMatchModel>>()
    val resWorkMatchModel = MutableLiveData<ResWorkNotMatchModel>()
    val resWorkMatchModelActive = MutableLiveData<ResWorkModel>()
    val resWorkOrderIdModel = MutableLiveData<ResWorkNotMatchModel>()
    val resWorkHistoryModel = MutableLiveData<List<ResWorkHistoryModel>>()
    var amLat = 0.00
    var amLong = 0.00
    fun createVolunteer(createVolunteerModel: CrateVolunteerModel) {
        val response = repository.createVolunteer(createVolunteerModel)
        response.enqueue(object : Callback<ResponseSuccessModel> {
            override fun onResponse(
                call: Call<ResponseSuccessModel>,
                response: Response<ResponseSuccessModel>
            ) {
                if (response.isSuccessful) {
                    resSuccessModel.postValue(response.body())
                } else {
                    resError.postValue("เกิดข้อผิดพลาด")
                }
            }

            override fun onFailure(call: Call<ResponseSuccessModel>, t: Throwable) {
                println(t.message)
            }

        })
    }

    fun loginVolunteer(loginModel: LoginModel) {
        val response = repository.loginVolunteer(loginModel)
        response.enqueue(object : Callback<ResTokenModel> {
            override fun onResponse(call: Call<ResTokenModel>, response: Response<ResTokenModel>) {
                if (response.isSuccessful) {
                    resTokenModel.postValue(response.body())
                } else {
                    resError.postValue("Login ไม่สำเร็จ")
                }

            }

            override fun onFailure(call: Call<ResTokenModel>, t: Throwable) {
                println(t.message)
            }

        })
    }

    fun findVolunteerInfo(token: String) {
        val response = repository.findVolunteerInfo(token)
        response.enqueue(object : Callback<ResVolunteerInfo> {
            override fun onResponse(
                call: Call<ResVolunteerInfo>,
                response: Response<ResVolunteerInfo>
            ) {
                if (response.isSuccessful) {
                    resVolunteerInfo.postValue(response.body())
                } else {
                    resError.postValue("ดึงข้อมูลไม่สำเร็จ")
                }

            }

            override fun onFailure(call: Call<ResVolunteerInfo>, t: Throwable) {
                resError.postValue("ดึงข้อมูลไม่สำเร็จ")
            }

        })
    }

    fun findWorkNotMatch(searchWorkModel: SearchWorkModel, view: View) {

        val response = repository.findWorkNotMatch(searchWorkModel)
        response.enqueue(object : Callback<List<ResWorkNotMatchModel>> {
            override fun onResponse(
                call: Call<List<ResWorkNotMatchModel>>,
                response: Response<List<ResWorkNotMatchModel>>
            ) {
                if (response.isSuccessful) {
                    resWorkNotMatchModel.postValue(response.body())
                } else {
                    resError.postValue("เกิดข้อผิดพลาด")
                }
            }

            override fun onFailure(call: Call<List<ResWorkNotMatchModel>>, t: Throwable) {
                resError.postValue("เชื่อมต่อไม่สำเร็จ")
            }

        })
    }

    fun findByIdOrder(searchOrder: SearchOrder) {
        val response = repository.findByIdOrder(searchOrder)
        response.enqueue(object : Callback<ResWorkNotMatchModel> {
            override fun onResponse(
                call: Call<ResWorkNotMatchModel>,
                response: Response<ResWorkNotMatchModel>
            ) {
                if (response.isSuccessful) {
                    resWorkOrderIdModel.postValue(response.body())
                } else {
                    resError.postValue("เกิดข้อผิดพลาด")
                }
            }

            override fun onFailure(call: Call<ResWorkNotMatchModel>, t: Throwable) {
                resError.postValue("ไม่สามารถดึงข้อมูลได้")
            }

        })
    }

    fun matchingUser(token: String, orderWork: OrderWork) {
        val response = repository.matchingUser(token, orderWork)
        response.enqueue(object : Callback<ResWorkNotMatchModel> {
            override fun onResponse(
                call: Call<ResWorkNotMatchModel>,
                response: Response<ResWorkNotMatchModel>
            ) {
                if (response.isSuccessful) {
                    resWorkMatchModel.postValue(response.body())
                } else {
                    resError.postValue("รับงานไม่สำเร็จ")
                }
            }

            override fun onFailure(call: Call<ResWorkNotMatchModel>, t: Throwable) {
                resError.postValue("เชื่อมต่อไม่สำเร็จ")
            }
        })
    }

    fun findMatchOn(token: String, searchWorkModel: SearchWorkModel) {
        val response = repository.findMatchOn(token, searchWorkModel)
        response.enqueue(object : Callback<ResWorkModel> {
            override fun onResponse(
                call: Call<ResWorkModel>,
                response: Response<ResWorkModel>
            ) {
                if (response.isSuccessful) {
                    resWorkMatchModelActive.postValue(response.body())
                } else {
                    resError.postValue("ไม่มีข้อมูล")
                }
            }

            override fun onFailure(call: Call<ResWorkModel>, t: Throwable) {
                resError.postValue("ไม่สามารถเชื่อมต่อได้")
            }

        })
    }

    fun changeStatusSuccess(token: String, searchMatchId: SearchMatchId) {
        val response = repository.changeStatusSuccess(token, searchMatchId)
        response.enqueue(object : Callback<ResponseSuccessModel> {
            override fun onResponse(
                call: Call<ResponseSuccessModel>,
                response: Response<ResponseSuccessModel>
            ) {
                if (response.isSuccessful) {
                    resSuccessModel.postValue(response.body())
                } else {
                    resError.postValue("ไม่สำเร็จ")
                }
            }

            override fun onFailure(call: Call<ResponseSuccessModel>, t: Throwable) {
                resError.postValue("เชื่อมต่อไม่ได้")
            }
        })
    }

    fun getHistoryMatchSuccessAll(token: String, searchWorkModel: SearchWorkModel) {
        val response = repository.getHistoryMatchSuccessAll(token, searchWorkModel)
        response.enqueue(object : Callback<List<ResWorkHistoryModel>> {
            override fun onResponse(
                call: Call<List<ResWorkHistoryModel>>,
                response: Response<List<ResWorkHistoryModel>>
            ) {
                if (response.isSuccessful) {
                    resWorkHistoryModel.postValue(response.body())
                } else {
                    resError.postValue("ไม่สำเร็จ")
                }
            }

            override fun onFailure(call: Call<List<ResWorkHistoryModel>>, t: Throwable) {
                resError.postValue("ไม่สามารถติดต่อได้")
            }
        })
    }

    fun saveImage(img: MultipartBody.Part) {
        val response = repository.saveImage(img)
        response.enqueue(object : Callback<String> {
            override fun onResponse(call: Call<String>, response: Response<String>) {
                resError.postValue(response.body())
            }

            override fun onFailure(call: Call<String>, t: Throwable) {
                println(t.message)
            }
        })
    }



}