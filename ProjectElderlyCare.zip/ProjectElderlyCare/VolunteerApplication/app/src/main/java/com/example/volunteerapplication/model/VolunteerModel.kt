package com.example.volunteerapplication.model

data class VolunteerModel(
    val test:String
)

data class CrateVolunteerModel(
    val volunteerAddress: String,
    val volunteerFirstname: String,
    val volunteerLastname: String,
    val volunteerPassword: String,
    val volunteerPhone: String,
    val volunteerUsername: String,
    val volunteerLineId:String
)

data class LoginModel(
    val volunteerUsername:String,
    val volunteerPassword:String
)


data class SearchWorkModel(
    val status:Int
)

data class SearchOrder(
    val orderId:Int
)

data class OrderWork(
    val orderWork:Int
)
data class SearchMatchId(
    val matchId:Int
)