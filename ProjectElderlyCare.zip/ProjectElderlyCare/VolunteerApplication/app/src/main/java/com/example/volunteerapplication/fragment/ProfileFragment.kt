package com.example.volunteerapplication.fragment

import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.volunteerapplication.R
import com.example.volunteerapplication.databinding.FragmentProfileBinding
import com.example.volunteerapplication.network.RetrofitService
import com.example.volunteerapplication.repository.MainRepository
import com.example.volunteerapplication.session.TokenManager
import com.example.volunteerapplication.viewmodel.MainViewModel
import com.example.volunteerapplication.viewmodelFactory.MainViewModelFactory
import okhttp3.*
import java.io.File
import java.util.*


class ProfileFragment : Fragment() {
    private val tokenManager = TokenManager()
    private lateinit var binding:FragmentProfileBinding
    lateinit var mainViewModel: MainViewModel
    val retrofitService = RetrofitService.getInstance()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentProfileBinding.inflate(layoutInflater,container, false)
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {


        loadDataInfo(view)
        binding.btnLogout.setOnClickListener {
            tokenManager.clearToken(view.context)
            findNavController().popBackStack()
            findNavController().popBackStack()
            findNavController().popBackStack()
            findNavController().popBackStack()
            findNavController().navigate(R.id.loginFragment)
        }


    }
    private fun loadDataInfo(view: View){

        mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
        mainViewModel.resVolunteerInfo.observe(viewLifecycleOwner){
            binding.tvFirstName.text = it.volunteerFirstname
            binding.tvLastName.text = it.volunteerLastname
            binding.tvPhoneNumber.text = it.volunteerPhone
        }
        mainViewModel.resError.observe(viewLifecycleOwner){
            Toast.makeText(view.context, it.toString(), Toast.LENGTH_SHORT).show()
        }
        mainViewModel.findVolunteerInfo("Bearer "+tokenManager.getToken(view.context))
    }






}