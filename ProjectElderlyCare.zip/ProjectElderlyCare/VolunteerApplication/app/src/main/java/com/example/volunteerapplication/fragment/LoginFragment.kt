package com.example.volunteerapplication.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.example.volunteerapplication.R
import com.example.volunteerapplication.databinding.FragmentLoginBinding
import com.example.volunteerapplication.model.LoginModel
import com.example.volunteerapplication.network.RetrofitService
import com.example.volunteerapplication.repository.MainRepository
import com.example.volunteerapplication.session.TokenManager
import com.example.volunteerapplication.viewmodel.MainViewModel
import com.example.volunteerapplication.viewmodelFactory.MainViewModelFactory


class LoginFragment : Fragment() {
    var tokenManager = TokenManager()
    lateinit var binding: FragmentLoginBinding
    lateinit var mainViewModel:MainViewModel
    val retrofitService = RetrofitService.getInstance()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentLoginBinding.inflate(layoutInflater, container, false)
        if (tokenManager.getToken(binding.root.context) != ""){
            findNavController().popBackStack()
            findNavController().navigate(R.id.homeFragment)
        }
        println(tokenManager.getToken(binding.root.context))
        // Inflate the layout for this fragment
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.btnLogin.setOnClickListener {
            var loginModel = LoginModel(
                volunteerUsername = binding.etUserNameLogin.text.toString(),
                volunteerPassword = binding.etPasswordLogin.text.toString()
            )
            mainViewModel = ViewModelProvider(this,MainViewModelFactory(MainRepository(retrofitService))).get(MainViewModel::class.java)
            mainViewModel.loginVolunteer(loginModel)
            mainViewModel.resTokenModel.observe(viewLifecycleOwner){
                tokenManager.setToken(view.context,it.token)
                findNavController().navigate(R.id.homeFragment)
            }
            mainViewModel.resError.observe(viewLifecycleOwner){
                Toast.makeText(view.context, it.toString(), Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnToRegisterPage.setOnClickListener {
            findNavController().popBackStack()
            findNavController().navigate(R.id.registerFragment)

        }
    }

}